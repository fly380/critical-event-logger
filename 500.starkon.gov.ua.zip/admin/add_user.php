<?php
// Показ усіх помилок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Перевірка прав доступу
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
	header('Location: /templates/login.php');
	exit;
}

// Підключення функцій
require_once __DIR__ . '/functions.php';

$error = '';
$pdo = connectToDatabase();

// Обробка форми
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$username = $_POST['username'] ?? '';
	$password = $_POST['password'] ?? '';
	$role = $_POST['role'] ?? 'user';

	if (empty($username) || empty($password)) {
		$error = 'Будь ласка, заповніть всі поля.';
	} elseif (userExists($pdo, $username)) {
		$error = 'Користувач з таким логіном вже існує.';
	} else {
		createUser($pdo, $username, $password, $role);
		header('Location: /admin/user_list.php');
		exit;
	}
}

// Починаємо буферизацію контенту
ob_start();
?>
		<!-- Основний контент -->
		   <h2 class="mb-4">Додавання нового користувача</h2>
   <a href="user_list.php" class="btn btn-secondary mb-3">Список користувачів</a>
	<?php if ($error): ?>
		<div class="alert alert-danger"><?= $error ?></div>
	<?php endif; ?>

	<form action="add_user.php" method="POST">
		<div class="mb-3">
			<label for="username" class="form-label">Логін</label>
			<input type="text" id="username" name="username" class="form-control" required>
		</div>
		<div class="mb-3">
			<label for="password" class="form-label">Пароль</label>
			<input type="password" id="password" name="password" class="form-control" required>
		</div>
		<div class="mb-3">
			<label for="role" class="form-label">Роль</label>
			<select id="role" name="role" class="form-control">
				<option value="user">Користувач</option>
				<option value="redaktor">Редактор</option>
				<option value="admin">Адміністратор</option>
			</select>
		</div>
		<button type="submit" class="btn btn-primary">Додати користувача</button>
	</form>
<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';