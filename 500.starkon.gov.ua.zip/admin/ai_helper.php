<?php
header('Content-Type: application/json');

// Додаємо логування помилок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$input = json_decode(file_get_contents('php://input'), true);
$prompt = "Відповідай українською. " . trim($input['prompt'] ?? '');

if (!$prompt) {
    echo json_encode(['error' => 'Немає prompt']);
    exit;
}

$apiKey = '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';

// ✅ АКТУАЛЬНІ МОДЕЛІ GROQ (на 2025 рік)
$models = [
    'llama-3.3-70b-versatile',    // Найпотужніша Llama 3.3
    'llama-3.1-8b-instant',       // Швидка Llama 3.1 (заміна для 8b-8192)
    'mixtral-8x7b-32768',         // Mixtral (хороша для складних задач)
    'gemma2-9b-it'                 // Google Gemma 2
];

// Використовуємо llama-3.1-8b-instant як заміну для старої моделі
$model = 'llama-3.1-8b-instant'; // Швидка та стабільна модель

// Якщо хочемо кращу якість - використовуємо llama-3.3-70b-versatile
// $model = 'llama-3.3-70b-versatile';

$data = [
    'model' => $model,
    'messages' => [
        ['role' => 'user', 'content' => $prompt]
    ],
    'max_tokens' => 1000,        // Збільшимо трохи
    'temperature' => 0.7
];

// Спроба через прямий API (без Cloudflare Gateway)
$url = 'https://api.groq.com/openai/v1/chat/completions';

$options = [
    'http' => [
        'method' => 'POST',
        'header' => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        ],
        'content' => json_encode($data),
        'timeout' => 30,
        'ignore_errors' => true
    ],
    'ssl' => [
        'verify_peer' => false,
        'verify_peer_name' => false
    ]
];

$context = stream_context_create($options);
$response = @file_get_contents($url, false, $context);

if ($response === false) {
    $error = error_get_last();
    echo json_encode([
        'error' => 'Помилка запиту до Groq',
        'details' => $error['message'] ?? 'Невідома помилка',
        'model_used' => $model
    ]);
    exit;
}

$result = json_decode($response, true);

if (isset($result['error'])) {
    // Якщо модель не працює, спробуємо іншу
    if ($model === 'llama-3.1-8b-instant' && strpos($result['error']['message'] ?? '', 'decommissioned') !== false) {
        // Спробуємо gemma2-9b-it
        $data['model'] = 'gemma2-9b-it';
        $options['http']['content'] = json_encode($data);
        $context = stream_context_create($options);
        $response = @file_get_contents($url, false, $context);
        
        if ($response !== false) {
            $result = json_decode($response, true);
        }
    }
    
    if (isset($result['error'])) {
        echo json_encode([
            'error' => 'Помилка API Groq',
            'details' => $result['error']
        ]);
        exit;
    }
}

$text = $result['choices'][0]['message']['content'] ?? 'Не вдалося згенерувати відповідь';
echo json_encode(['text' => $text]);
?>