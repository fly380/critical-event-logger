<?php
// Показ усіх помилок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/../admin/functions.php';
require_once __DIR__ . '/../data/log_action.php';
require_once __DIR__ . '/../plugins/ukr_to_lat.php';
$title = $_POST['title'] ?? '';
$slug = $_POST['slug'] ?? ctl_transliterate($title);

$username = $_SESSION['username'] ?? 'невідомо';
$message = '';

// Підключення до бази даних через функцію
$pdo = connectToDatabase();

// Створення нової сторінки
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_page_slug'])) {
	$rawTitle = trim($_POST['new_page_slug']);
	$slug = ctl_transliterate($rawTitle); // 🟩 транслітерація тут

	// Перевірка, чи вже існує
	$stmt = $pdo->prepare("SELECT COUNT(*) FROM pages WHERE slug = ?");
	$stmt->execute([$slug]);
	if ($stmt->fetchColumn() > 0) {
		$message = "Сторінка з таким ім’ям вже існує!";
	} else {
		$title = ucfirst($rawTitle); // для заголовку сторінки
		$content = '<p>Новий контент...</p>';
		$draft = isset($_POST['draft']) ? 1 : 0;
		$visibility = isset($_POST['auth_only']) ? 'private' : 'public';

		$stmt = $pdo->prepare("INSERT INTO pages (slug, title, content, draft, visibility, created_at) VALUES (?, ?, ?, ?, ?, datetime('now'))");
		$stmt->execute([$slug, $title, $content, $draft, $visibility]);

		log_action("📄 Створив нову сторінку '{$slug}'", $username);
		header("Location: edit_page.php?page=" . urlencode($slug));
		exit;
	}
}

// Видалення сторінки
if (isset($_GET['delete'])) {
	$deleteSlug = basename($_GET['delete']);
	$stmt = $pdo->prepare("DELETE FROM pages WHERE slug = ?");
	$stmt->execute([$deleteSlug]);
	$message = "Сторінку <strong>{$deleteSlug}</strong> видалено.";
	log_action("🗑️ Видалив сторінку '{$deleteSlug}'", $username);
}

// Отримання списку сторінок
$stmt = $pdo->query("SELECT slug, title, draft, visibility FROM pages ORDER BY created_at DESC");
$pages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Створюємо контент через буфер виводу
ob_start();
?>

<!-- Основний контент -->
<div class="col-md-9 col-lg-10 p-4">
	<h1 class="h4 mb-4">Сторінки</h1>

	<?php if (!empty($message)): ?>
		<div class="alert alert-info"><?= $message ?></div>
	<?php endif; ?>

	<h5>Оберіть сторінку для редагування:</h5>
	<ul class="list-group mb-4">
		<li class="list-group-item d-flex justify-content-between align-items-center">
			<span>Головна</span>
			<div>
				<a href="edit_page.php?page=main" class="btn btn-sm btn-outline-primary me-2">Редагувати</a>
			</div>
		</li>
		<?php foreach ($pages as $page): ?>
			<li class="list-group-item d-flex justify-content-between align-items-center">
				<span>
				 <strong><?= htmlspecialchars($page['title'] ?? '') ?></strong> /<?= htmlspecialchars($page['slug']) ?>
				 <?php if (!empty($page['draft'])): ?>
				 <span class="badge bg-warning text-dark ms-2">Чернетка</span>
				 <?php elseif (!empty($page['visibility']) && $page['visibility'] === 'private'): ?>
				 <span class="badge bg-secondary ms-2">Приватна</span>
				 <?php endif; ?>
				</span>
				<div>
					<a href="edit_page.php?page=<?= urlencode($page['slug']) ?>" class="btn btn-sm btn-outline-primary me-2">Редагувати</a>
					<a href="?delete=<?= urlencode($page['slug']) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Ви дійсно хочете видалити сторінку &quot;<?= $page['slug'] ?>&quot;?')">Видалити</a>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>

	<h4>Створити нову сторінку</h4>
	<form method="POST" class="row g-3">
		<div class="col-auto">
			<input type="text" name="new_page_slug" class="form-control" placeholder="Назва сторінки URL" required>
		</div>
		<div class="col-auto form-check">
			<input class="form-check-input" type="checkbox" name="draft" id="draft">
			<label class="form-check-label" for="draft">Чорнетка</label>
		</div>
		<div class="col-auto form-check">
			<input class="form-check-input" type="checkbox" name="auth_only" id="auth_only">
			<label class="form-check-label" for="auth_only">Лише для авторизованих</label>
		</div>
		<div class="col-auto">
			<button type="submit" class="btn btn-success">Створити сторінку</button>
		</div>
	</form>
</div>
<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
