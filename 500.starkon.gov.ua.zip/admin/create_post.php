<?php
// create_post.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

require_once __DIR__ . '/../admin/functions.php';
require_once __DIR__ . '/../plugins/ukr_to_lat.php';
require_once __DIR__ . '/../data/log_action.php';

$pdo = connectToDatabase();
$username = $_SESSION['username'] ?? 'невідомо';
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_post_title'])) {
	$title = trim($_POST['new_post_title']);
	$slug = ctl_transliterate($title);
	$content = '<p>Новий запис...</p>';
	$draft = isset($_POST['draft']) ? 1 : 0;
	$visibility = isset($_POST['auth_only']) ? 'private' : 'public';
	$meta_title = trim($_POST['meta_title'] ?? '');
	$meta_description = trim($_POST['meta_description'] ?? '');
	$show_on_main = isset($_POST['show_on_main']) ? 1 : 0;

	// Перевірка на унікальність slug
	$stmt = $pdo->prepare("SELECT COUNT(*) FROM posts WHERE slug = ?");
	$stmt->execute([$slug]);
	if ($stmt->fetchColumn() > 0) {
		$message = "⚠️ Запис із таким slug вже існує.";
	} else {
		$stmt = $pdo->prepare("INSERT INTO posts (slug, title, content, draft, visibility, show_on_main, meta_title, meta_description, created_at, updated_at) 
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))");
		$stmt->execute([$slug, $title, $content, $draft, $visibility, $show_on_main, $meta_title, $meta_description]);
		log_action("📮 Створив новий запис '$slug'", $username);
		header("Location: edit_post.php?post=" . urlencode($slug));
		exit;
	}
}

// Видалення сторінки
if (isset($_GET['delete'])) {
    $deleteSlug = basename($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM posts WHERE slug = ?");
    $stmt->execute([$deleteSlug]);
    $message = "Запис <strong>{$deleteSlug}</strong> видалено.";
    log_action("Видалив запис '{$deleteSlug}'", $username);
}

// Отримання записів
$stmt = $pdo->query("SELECT slug, title, meta_title, draft, visibility, created_at FROM posts ORDER BY created_at DESC");
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Вивід
ob_start();
?>
<div class="col-md-9 col-lg-10 p-4">
	<h1 class="h4 mb-4">Блог — Записи</h1>

	<?php if (!empty($message)): ?>
		<div class="alert alert-warning"><?= $message ?></div>
	<?php endif; ?>

	<ul class="list-group mb-4">
		<?php foreach ($posts as $post): ?>
			<li class="list-group-item d-flex justify-content-between align-items-center">
				<div>
					<strong><?= htmlspecialchars($post['meta_title'] ?? '') ?></strong>
					<small class="text-muted ms-2"><?= htmlspecialchars($post['created_at']) ?></small>
					<?php if ($post['draft']): ?><span class="badge bg-warning text-dark ms-2">Чернетка</span><?php endif; ?>
					<?php if ($post['visibility'] === 'private'): ?><span class="badge bg-secondary ms-2">Приватний</span><?php endif; ?>
				</div>
				<div>
					<a href="edit_post.php?post=<?= urlencode($post['slug']) ?>" class="btn btn-sm btn-outline-primary me-2">Редагувати</a>
					<a href="?delete=<?= urlencode($post['slug']) ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Видалити запис?')">Видалити</a>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>

	<h4>Створити новий запис</h4>
	<form method="POST" class="row g-3">
		<div class="col-md-6">
			<input type="text" name="new_post_title" class="form-control" placeholder="Назва запису URL" required>
		</div>
		<div class="col-md-6">
			<input type="text" name="meta_title" class="form-control" placeholder="Заголовок">
		</div>
		<div class="col-auto form-check">
			<input class="form-check-input" type="checkbox" name="draft" id="draft">
			<label class="form-check-label" for="draft">Чернетка</label>
		</div>
		<div class="col-auto form-check">
			<input class="form-check-input" type="checkbox" name="auth_only" id="auth_only">
			<label class="form-check-label" for="auth_only">Лише для авторизованих</label>
		</div>
		<div class="col-auto form-check">
			<input class="form-check-input" type="checkbox" name="show_on_main" id="show_on_main" checked>
			<label class="form-check-label" for="show_on_main">Показувати на головній</label>
		</div>
		<div class="col-12">
			<button type="submit" class="btn btn-success">Створити запис</button>
		</div>
	</form>
</div>
<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
