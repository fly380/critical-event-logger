<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();

require_once __DIR__ . '/../admin/functions.php';
require_once __DIR__ . '/../data/log_action.php';

$username = $_SESSION['username'] ?? 'невідомо';

// Якщо не вказано сторінку, редагуємо головну
$pageSlug = $_GET['page'] ?? 'main';

// Підключення до БД через функцію
$pdo = connectToDatabase();

$isLocked = false;
$lockedBy = '';
$message = '';

// Обробка блокування сторінки (тільки для сторінок, які не є головною)
$lockFile = null;
if ($pageSlug !== 'main') {
	$lockFile = __DIR__ . '/../data/locks/' . $pageSlug . '.lock';
	if (file_exists($lockFile)) {
		$lockedBy = trim(file_get_contents($lockFile));
		if ($lockedBy !== $username) {
			$isLocked = true;
		}
	} else {
		file_put_contents($lockFile, $username);
		log_action("Заблокував сторінку '$pageSlug'", $username);
	}
}

// Обробка POST-запиту збереження
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$isLocked) {
	// CSRF захист можна додати пізніше

	$title = $_POST['title'] ?? '';
	$content = $_POST['content'] ?? '';
	$custom_css = $_POST['custom_css'] ?? '';
	$custom_js = $_POST['custom_js'] ?? '';


	if ($pageSlug === 'main') {
		// Збереження головної сторінки
		$stmt = $pdo->query("SELECT COUNT(*) FROM main_page WHERE id = 1");
		$exists = $stmt->fetchColumn() > 0;

		if ($exists) {
			$stmt = $pdo->prepare("UPDATE main_page SET title = :title, content = :content WHERE id = 1");
		} else {
			$stmt = $pdo->prepare("INSERT INTO main_page (id, title, content) VALUES (1, :title, :content)");
		}
		$stmt->execute([':title' => $title, ':content' => $content]);
		$message = "Зміни збережено!";
		log_action("📝 Оновлено головну сторінку", $username);

	} else {
		// Збереження звичайної сторінки
		$draft = isset($_POST['draft']) ? 1 : 0;
		$visibility = in_array($_POST['visibility'] ?? '', ['public', 'private']) ? $_POST['visibility'] : 'public';

		$stmt = $pdo->prepare("UPDATE pages SET title = :title, content = :content, draft = :draft, visibility = :visibility, custom_css = :custom_css, custom_js = :custom_js WHERE slug = :slug");
		$stmt->execute([
			':title' => $title,
			':content' => $content,
			':draft' => $draft,
			':visibility' => $visibility,
			':custom_css' => $custom_css,
			':custom_js' => $custom_js,
			':slug' => $pageSlug
		]);
		$message = "Зміни збережено!";
		log_action("Зберіг сторінку '$pageSlug'", $username);

		// Розблокування сторінки
		if ($lockFile && file_exists($lockFile)) {
			unlink($lockFile);
			log_action("Розблокував сторінку '$pageSlug'", $username);
		}
	}
}

// Отримання даних сторінки для форми
if ($pageSlug === 'main') {
	$stmt = $pdo->query("SELECT * FROM main_page WHERE id = 1");
	$pageData = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['title' => '', 'content' => ''];
} else {
	$stmt = $pdo->prepare("SELECT * FROM pages WHERE slug = :slug");
	$stmt->execute([':slug' => $pageSlug]);
	$pageData = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}

// Починаємо буферизацію виводу
ob_start();
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="/assets/tinymce/tinymce.min.js"></script>
<script>
tinymce.init({
	selector: 'textarea:not(.no-editor)',
	language_url: '/assets/tinymce/langs/uk.js',
	language: 'uk',
	license_key: 'off',
	height: 700,
	toolbar_mode: 'wrap',
	plugins: [
		'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
		'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
		'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount', 'emoticons'
	],
	toolbar: 'aihelper | undo redo | styles | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media table preview code fullscreen | help',

	// 📁 Підключення медіа-вікна
	file_picker_callback: function (callback, value, meta) {
		if (meta.filetype === 'image') {
			const win = window.open('/admin/media_picker.php', 'media', 'width=800,height=600');
			window.tinymceImageCallback = callback; // зберігаємо callback глобально
		}
	},

	// 🤖 AI-помічник з індикатором завантаження та детальною діагностикою
setup: function (editor) {
    editor.ui.registry.addButton('aihelper', {
        text: '🤖 ШІ-помічник',
        onAction: function () {
            const userPrompt = prompt("Введіть запит для генерації:");
            if (userPrompt) {
                // Знаходимо кнопку
                const button = document.querySelector('.tox-tbtn[aria-label="🤖 ШІ-помічник"]');
                const originalText = button ? button.innerHTML : '🤖 ШІ-помічник';
                
                if (button) {
                    button.innerHTML = '⏳ Генерація...';
                }
                
                const timeoutId = setTimeout(() => {
                    alert("Запит виконується довше ніж зазвичай. Будь ласка, зачекайте...");
                }, 10000);
                
                fetch('ai_helper.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ prompt: userPrompt })
                })
                .then(res => res.text())
                .then(text => {
                    clearTimeout(timeoutId);
                    console.log('Відповідь від сервера:', text); // Логуємо для діагностики
                    
                    try {
                        const data = JSON.parse(text);
                        if (data.text) {
                            editor.insertContent(data.text);
                        } else if (data.error) {
                            alert("Помилка: " + data.error + (data.details ? "\n\nДеталі: " + data.details : ""));
                        } else {
                            alert("Помилка генерації: невідома відповідь");
                        }
                    } catch (e) {
                        alert("Сервер повернув некоректну відповідь. Перевірте консоль (F12)");
                        console.error("Помилка парсингу JSON:", text);
                    }
                })
                .catch(error => {
                    clearTimeout(timeoutId);
                    alert("Помилка з'єднання: " + error.message);
                })
                .finally(() => {
                    if (button) {
                        button.innerHTML = originalText;
                    }
                });
            }
        }
    });
},

	content_style: 'body { font-family:Arial,sans-serif; font-size:14px }'
});
</script>
<script>
function wrapTables() {
	const editor = tinymce.get('editor');
	const wrapper = document.createElement('div');
	wrapper.innerHTML = editor.getContent();

	wrapper.querySelectorAll('table').forEach(function(table) {
		const parent = table.parentElement;
		if (!parent.classList.contains('table-responsive')) {
			const div = document.createElement('div');
			div.className = 'table-responsive';
			parent.replaceChild(div, table);
			div.appendChild(table);
		}
	});

	editor.setContent(wrapper.innerHTML);
}
</script>

<style>
	body {
		background: #3B4346 url("/assets/images/bg01.jpg");
	}
	.editor-header {
		background-color: #ffffff;
		border-bottom: 1px solid #dee2e6;
		padding: 20px;
		margin-bottom: 20px;
		border-radius: 8px;
	}
	.editor-form {
		background-color: #d6d2d2;
		padding: 30px;
		border-radius: 8px;
		box-shadow: 0 2px 10px rgba(0,0,0,0.05);
	}
</style>
<div class="container">
	<div class="editor-header d-flex justify-content-between align-items-center">
		<h1 class="h4 mb-0"><?= $pageSlug === 'main' ? 'Редагування головної сторінки' : 'Редагування сторінки: ' . htmlspecialchars($pageSlug) ?></h1>
	</div>

	<?php if (!empty($message)): ?>
		<div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
	<?php endif; ?>

	<?php if ($isLocked): ?>
		<div class="alert alert-warning">⚠ Сторінку зараз редагує <strong><?= htmlspecialchars($lockedBy) ?></strong>. Ви не можете її редагувати.</div>
	<?php endif; ?>

	<form method="POST" onsubmit="wrapTables();" class="editor-form" <?= $isLocked ? 'style="pointer-events:none;opacity:0.6;"' : '' ?>>
		<div class="mb-3">
			<label class="form-label">Заголовок</label>
			<input type="text" name="title" class="form-control" value="<?= htmlspecialchars($pageData['title'] ?? '') ?>" <?= $isLocked ? 'disabled' : '' ?>>
		</div>
		<div class="mb-3">
			<label class="form-label">Контент</label>
			<textarea name="content" <?= $isLocked ? 'disabled' : '' ?>><?= htmlspecialchars($pageData['content'] ?? '') ?></textarea>
		</div>
		<!-- користувалькі css та js -->
		<?php if ($_SESSION['role'] === 'admin'): ?>
	<div class="form-check mb-2">
		<input class="form-check-input" type="checkbox" id="toggleCss">
		<label class="form-check-label" for="toggleCss">Додати користувацький CSS</label>
	</div>
	<div class="mb-3 d-none" id="cssField">
		<label class="form-label">Користувацький CSS (буде вставлено в &lt;style&gt; на сторінці)</label>
		<textarea name="custom_css" class="form-control no-editor" rows="5" <?= $isLocked ? 'disabled' : '' ?>><?= htmlspecialchars($pageData['custom_css'] ?? '') ?></textarea>
	</div>

	<div class="form-check mb-2">
		<input class="form-check-input" type="checkbox" id="toggleJs">
		<label class="form-check-label" for="toggleJs">Додати користувацький JS</label>
	</div>
	<div class="mb-3 d-none" id="jsField">
		<label class="form-label">Користувацький JS (буде вставлено в &lt;script&gt; перед &lt;/body&gt;)</label>
		<textarea name="custom_js" class="form-control no-editor" rows="5" <?= $isLocked ? 'disabled' : '' ?>><?= htmlspecialchars($pageData['custom_js'] ?? '') ?></textarea>
	</div>
	<?php endif; ?>

		<?php if ($pageSlug !== 'main'): ?>
			<div class="form-check mb-3">
				<input class="form-check-input" type="checkbox" name="draft" id="draft" value="1" <?= !empty($pageData['draft']) ? 'checked' : '' ?> <?= $isLocked ? 'disabled' : '' ?>>
				<label class="form-check-label" for="draft">Зберегти як чернетку</label>
			</div>
			<div class="mb-3">
				<label class="form-label">Видимість сторінки</label>
				<select name="visibility" class="form-select" <?= $isLocked ? 'disabled' : '' ?>>
					<option value="public" <?= (isset($pageData['visibility']) && $pageData['visibility'] === 'public') ? 'selected' : '' ?>>Для всіх</option>
					<option value="private" <?= (isset($pageData['visibility']) && $pageData['visibility'] === 'private') ? 'selected' : '' ?>>Тільки для авторизованих</option>
				</select>
			</div>
		<?php endif; ?>
		<button type="submit" class="btn btn-primary" <?= $isLocked ? 'disabled' : '' ?>>💾 Зберегти</button>
	</form>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
	const toggleCss = document.getElementById('toggleCss');
	const cssField = document.getElementById('cssField');
	const toggleJs = document.getElementById('toggleJs');
	const jsField = document.getElementById('jsField');

	// Автовідображення, якщо вже є збережені значення
	if (document.querySelector('[name="custom_css"]').value.trim() !== "") {
		toggleCss.checked = true;
		cssField.classList.remove('d-none');
	}
	if (document.querySelector('[name="custom_js"]').value.trim() !== "") {
		toggleJs.checked = true;
		jsField.classList.remove('d-none');
	}

	toggleCss.addEventListener('change', function () {
		cssField.classList.toggle('d-none', !this.checked);
	});

	toggleJs.addEventListener('change', function () {
		jsField.classList.toggle('d-none', !this.checked);
	});
});
</script>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';