<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/../admin/functions.php';
require_once __DIR__ . '/../data/log_action.php';

$username = $_SESSION['username'] ?? 'невідомо';
$postSlug = $_GET['post'] ?? '';
if (!$postSlug) {
	die("❌ Не вказано пост.");
}

$pdo = connectToDatabase();
$message = '';

// Отримання існуючого поста
$stmt = $pdo->prepare("SELECT * FROM posts WHERE slug = :slug");
$stmt->execute([':slug' => $postSlug]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$post) {
	die("❌ Пост не знайдено.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$title = $_POST['title'] ?? '';
	$content = $_POST['content'] ?? '';
	$draft = isset($_POST['draft']) ? 1 : 0;
	$visibility = in_array($_POST['visibility'] ?? '', ['public', 'private']) ? $_POST['visibility'] : 'public';
	$show_on_main = isset($_POST['show_on_main']) ? 1 : 0;
	$meta_title = $_POST['meta_title'] ?? '';
	$meta_description = $_POST['meta_description'] ?? '';

	$thumbnailPath = $post['thumbnail'] ?? '';
	$oldThumbnailPath = $post['thumbnail'] ?? ''; // Зберігаємо стару мініатюру

	// Функція для безпечного видалення файлу
	function safeDeleteFile($filePath) {
		if (empty($filePath)) return false;
		
		// Конвертуємо веб-шлях в файловий шлях
		$fullPath = $_SERVER['DOCUMENT_ROOT'] . $filePath;
		
		// Перевіряємо чи файл існує і чи це дійсно файл в директорії uploads
		if (file_exists($fullPath) && is_file($fullPath) && strpos($fullPath, '/uploads/') !== false) {
			return unlink($fullPath);
		}
		return false;
	}

	// 1. Якщо завантажено зображення вручну
	if (!empty($_FILES['thumbnail']['name'])) {
		// Видаляємо стару мініатюру перед завантаженням нової
		if (!empty($oldThumbnailPath)) {
			safeDeleteFile($oldThumbnailPath);
			log_action("🗑️ Видалено стару мініатюру: $oldThumbnailPath", $username);
		}

		$uploadDir = __DIR__ . '/../uploads/posts/';
		if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
		
		// Генеруємо унікальне ім'я файлу
		$ext = strtolower(pathinfo($_FILES['thumbnail']['name'], PATHINFO_EXTENSION));
		$filename = uniqid('post_') . '_' . time() . '.' . $ext;
		$targetPath = $uploadDir . $filename;
		
		// Валідація зображення
		$allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
		$maxSize = 5 * 1024 * 1024; // 5MB
		
		if (!in_array($_FILES['thumbnail']['type'], $allowedTypes)) {
			$message = "❌ Недопустимий тип файлу. Дозволено: JPG, PNG, GIF, WEBP";
		} elseif ($_FILES['thumbnail']['size'] > $maxSize) {
			$message = "❌ Файл занадто великий. Максимум 5MB";
		} elseif (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $targetPath)) {
			$thumbnailPath = '/uploads/posts/' . $filename;
			log_action("📤 Завантажено нову мініатюру: $thumbnailPath", $username);
		}
	}

	// 2. Якщо мініатюра не задана — шукаємо <img> у контенті
	if (empty($thumbnailPath) && !empty($content)) {
		libxml_use_internal_errors(true);
		$doc = new DOMDocument();
		$doc->loadHTML('<?xml encoding="utf-8" ?>' . $content);
		$xpath = new DOMXPath($doc);
		$img = $xpath->query('//img')->item(0);

		if ($img) {
			$src = $img->getAttribute('src');
			
			// Перевіряємо чи це зовнішнє зображення
			$isExternal = filter_var($src, FILTER_VALIDATE_URL) && strpos($src, $_SERVER['HTTP_HOST']) === false;
			
			if ($isExternal) {
				// Спроба завантажити зовнішнє зображення
				$message .= "⚠️ Зовнішнє зображення виявлено. Спроба завантажити... ";
				
				// Завантажуємо зовнішнє зображення
				$ch = curl_init($src);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
				curl_setopt($ch, CURLOPT_TIMEOUT, 10);
				curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
				$imageData = curl_exec($ch);
				$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				$contentType = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
				curl_close($ch);
				
				if ($httpCode === 200 && $imageData) {
					// Визначаємо розширення з Content-Type або URL
					if (strpos($contentType, 'jpeg') !== false || strpos($contentType, 'jpg') !== false) {
						$ext = 'jpg';
					} elseif (strpos($contentType, 'png') !== false) {
						$ext = 'png';
					} elseif (strpos($contentType, 'gif') !== false) {
						$ext = 'gif';
					} elseif (strpos($contentType, 'webp') !== false) {
						$ext = 'webp';
					} else {
						$ext = pathinfo(parse_url($src, PHP_URL_PATH), PATHINFO_EXTENSION);
					}
					
					// Зберігаємо зображення локально
					$uploadDir = __DIR__ . '/../uploads/posts/';
					if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
					
					$localFilename = uniqid('external_') . '_' . time() . '.' . $ext;
					$localPath = $uploadDir . $localFilename;
					
					if (file_put_contents($localPath, $imageData)) {
						$src = '/uploads/posts/' . $localFilename;
						$srcPath = $localPath;
						$message .= "✅ Зовнішнє зображення завантажено локально. ";
						log_action("🌐 Завантажено зовнішнє зображення: $src", $username);
					} else {
						error_log("Не вдалося зберегти зовнішнє зображення: $src");
						$message .= "❌ Не вдалося зберегти зовнішнє зображення. ";
					}
				} else {
					error_log("Не вдалося завантажити зовнішнє зображення: $src (HTTP: $httpCode)");
					$message .= "❌ Не вдалося завантажити зовнішнє зображення. ";
				}
			}
			
			// Нормалізація — прибираємо ../, лишаємо абсолютний шлях від кореня сайту
			$srcClean = preg_replace('#^(\.\./)+#', '', $src);
			if (strpos($srcClean, '/') !== 0) {
				$srcClean = '/' . $srcClean;
			}

			// Безпечне визначення шляху
			$baseDir = realpath(__DIR__ . '/..');
			$srcPath = $baseDir . $srcClean;
			
			// Перевіряємо чи файл існує і знаходиться в межах uploads директорії
			$uploadsDir = realpath(__DIR__ . '/../uploads');
			if (file_exists($srcPath) && strpos($srcPath, $uploadsDir) === 0) {
				$ext = strtolower(pathinfo($srcPath, PATHINFO_EXTENSION));
				$thumbDir = __DIR__ . '/../uploads/thumbs/';
				if (!is_dir($thumbDir)) mkdir($thumbDir, 0777, true);

				$thumbName = pathinfo($srcPath, PATHINFO_FILENAME) . '_thumb_' . time() . '.' . $ext;
				$thumbPath = $thumbDir . $thumbName;
				$thumbWebPath = '/uploads/thumbs/' . $thumbName;

				// Створюємо ресурс зображення
				$imgRes = null;
				switch ($ext) {
					case 'jpg':
					case 'jpeg':
						$imgRes = imagecreatefromjpeg($srcPath);
						break;
					case 'png':
						$imgRes = imagecreatefrompng($srcPath);
						break;
					case 'gif':
						$imgRes = imagecreatefromgif($srcPath);
						break;
					case 'webp':
						if (function_exists('imagecreatefromwebp')) {
							$imgRes = imagecreatefromwebp($srcPath);
						}
						break;
				}

				if ($imgRes) {
					$origW = imagesx($imgRes);
					$origH = imagesy($imgRes);
					$targetW = 300;
					$targetH = 200;

					$ratio = min($targetW / $origW, $targetH / $origH);
					$newW = (int)($origW * $ratio);
					$newH = (int)($origH * $ratio);

					$thumbRes = imagecreatetruecolor($newW, $newH);
					
					// Зберігаємо прозорість для PNG
					if ($ext === 'png') {
						imagealphablending($thumbRes, false);
						imagesavealpha($thumbRes, true);
					}
					
					imagecopyresampled($thumbRes, $imgRes, 0, 0, 0, 0, $newW, $newH, $origW, $origH);

					// Зберігаємо мініатюру
					$success = false;
					if (in_array($ext, ['jpg', 'jpeg'])) {
						$success = imagejpeg($thumbRes, $thumbPath, 85);
					} elseif ($ext === 'png') {
						$success = imagepng($thumbRes, $thumbPath, 9);
					} elseif ($ext === 'gif') {
						$success = imagegif($thumbRes, $thumbPath);
					} elseif ($ext === 'webp' && function_exists('imagewebp')) {
						$success = imagewebp($thumbRes, $thumbPath, 85);
					}

					imagedestroy($imgRes);
					imagedestroy($thumbRes);

					if ($success) {
						// Видаляємо стару мініатюру перед збереженням нової
						if (!empty($oldThumbnailPath) && $oldThumbnailPath !== $thumbnailPath) {
							safeDeleteFile($oldThumbnailPath);
							log_action("🗑️ Видалено стару мініатюру: $oldThumbnailPath", $username);
						}
						
						$thumbnailPath = $thumbWebPath;
						log_action("🖼️ Створено нову мініатюру: $thumbWebPath", $username);
					} else {
						error_log("Не вдалося записати мініатюру: $thumbPath");
					}
				} else {
					error_log("Не вдалося створити ресурс зображення: $srcPath");
				}
			} else {
				error_log("❌ Файл не існує або поза межами uploads: $srcPath");
			}
		}
		libxml_clear_errors();
	}
	
	// Якщо користувач явно видалив мініатюру (через чекбокс)
	if (isset($_POST['remove_thumbnail']) && $_POST['remove_thumbnail'] === '1') {
		if (!empty($oldThumbnailPath)) {
			safeDeleteFile($oldThumbnailPath);
			log_action("🗑️ Видалено мініатюру за запитом: $oldThumbnailPath", $username);
		}
		$thumbnailPath = ''; // Очищаємо шлях в БД
	}
	
	// 3. Оновлення запису
	$stmt = $pdo->prepare("UPDATE posts SET 
		title = :title,
		content = :content,
		draft = :draft,
		visibility = :visibility,
		show_on_main = :show_on_main,
		meta_title = :meta_title,
		meta_description = :meta_description,
		thumbnail = :thumbnail,
		updated_at = datetime('now')
		WHERE slug = :slug");

	$stmt->execute([
		':title' => $title,
		':content' => $content,
		':draft' => $draft,
		':visibility' => $visibility,
		':show_on_main' => $show_on_main,
		':meta_title' => $meta_title,
		':meta_description' => $meta_description,
		':thumbnail' => $thumbnailPath,
		':slug' => $postSlug
	]);

	$message = "✅ Запис оновлено.";
	log_action("📝 Оновив пост '$postSlug'", $username);
}
?>
<?php ob_start(); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="/assets/tinymce/tinymce.min.js"></script>
<script>
tinymce.init({
	selector: 'textarea:not(.no-editor)',
	language_url: '/assets/tinymce/langs/uk.js',
	language: 'uk',
	license_key: 'off',
	height: 700,
	toolbar_mode: 'wrap',
	plugins: [
		'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
		'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
		'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount', 'emoticons'
	],
	toolbar: 'aihelper | undo redo | styles | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media table preview code fullscreen | help',

	// 📁 Підключення медіа-вікна
	file_picker_callback: function (callback, value, meta) {
		if (meta.filetype === 'image') {
			const win = window.open('/admin/media_picker.php', 'media', 'width=800,height=600');
			window.tinymceImageCallback = callback; // зберігаємо callback глобально
		}
	},

	// 🤖 AI-помічник з індикатором завантаження та детальною діагностикою
setup: function (editor) {
    editor.ui.registry.addButton('aihelper', {
        text: '🤖 ШІ-помічник',
        onAction: function () {
            const userPrompt = prompt("Введіть запит для генерації:");
            if (userPrompt) {
                // Знаходимо кнопку
                const button = document.querySelector('.tox-tbtn[aria-label="🤖 ШІ-помічник"]');
                const originalText = button ? button.innerHTML : '🤖 ШІ-помічник';
                
                if (button) {
                    button.innerHTML = '⏳ Генерація...';
                }
                
                const timeoutId = setTimeout(() => {
                    alert("Запит виконується довше ніж зазвичай. Будь ласка, зачекайте...");
                }, 10000);
                
                fetch('ai_helper.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ prompt: userPrompt })
                })
                .then(res => res.text())
                .then(text => {
                    clearTimeout(timeoutId);
                    console.log('Відповідь від сервера:', text); // Логуємо для діагностики
                    
                    try {
                        const data = JSON.parse(text);
                        if (data.text) {
                            editor.insertContent(data.text);
                        } else if (data.error) {
                            alert("Помилка: " + data.error + (data.details ? "\n\nДеталі: " + data.details : ""));
                        } else {
                            alert("Помилка генерації: невідома відповідь");
                        }
                    } catch (e) {
                        alert("Сервер повернув некоректну відповідь. Перевірте консоль (F12)");
                        console.error("Помилка парсингу JSON:", text);
                    }
                })
                .catch(error => {
                    clearTimeout(timeoutId);
                    alert("Помилка з'єднання: " + error.message);
                })
                .finally(() => {
                    if (button) {
                        button.innerHTML = originalText;
                    }
                });
            }
        }
    });
},
	content_style: 'body { font-family:Arial,sans-serif; font-size:14px }'
});
</script>
<div class="container py-4">
	<h1 class="h4 mb-4">Редагування запису: <?= htmlspecialchars($postSlug) ?></h1>

	<?php if (!empty($message)): ?>
		<div class="alert alert-success"><?= $message ?></div>
	<?php endif; ?>

	<form method="POST" enctype="multipart/form-data">
		<div class="mb-3">
			<label class="form-label">Мета-заголовок (SEO)</label>
			<input type="text" name="meta_title" class="form-control" value="<?= htmlspecialchars($post['meta_title'] ?? '') ?>">
		</div>

		<!-- 👇 ЄДИНЕ поле для контенту (без class="form-control" для TinyMCE) -->
		<div class="mb-3">
			<label class="form-label">Контент</label>
			<textarea name="content"><?= htmlspecialchars($post['content']) ?></textarea>
		</div>
		<!-- 👆 -->

		<!-- Блок з мініатюрою -->
		<div class="mb-3">
			<label class="form-label">Поточна мініатюра:</label>
			<?php if (!empty($post['thumbnail'])): ?>
				<div class="mb-2">
					<img src="<?= htmlspecialchars($post['thumbnail']) ?>" alt="Thumbnail" style="max-width: 200px; max-height: 150px;" class="border rounded">
				</div>
				<div class="form-check mb-2">
					<input class="form-check-input" type="checkbox" name="remove_thumbnail" id="remove_thumbnail" value="1">
					<label class="form-check-label text-danger" for="remove_thumbnail">
						🗑️ Видалити поточну мініатюру
					</label>
				</div>
			<?php else: ?>
				<p class="text-muted">Мініатюра не встановлена</p>
			<?php endif; ?>
		</div>

		<div class="mb-3">
			<label class="form-label">Завантажити нову мініатюру:</label>
			<input type="file" name="thumbnail" class="form-control" accept="image/jpeg,image/png,image/gif,image/webp">
			<small class="text-muted">Максимальний розмір: 5MB. Дозволені формати: JPG, PNG, GIF, WEBP</small>
		</div>
		<!-- Кінець блоку з мініатюрою -->

		<div class="mb-3">
			<label class="form-label">Мета-опис (SEO)</label>
			<!-- 👇 Додано клас no-editor, щоб TinyMCE не ініціалізував це поле -->
			<textarea name="meta_description" class="form-control no-editor" rows="3"><?= htmlspecialchars($post['meta_description'] ?? '') ?></textarea>
			<!-- 👆 -->
		</div>

		<div class="mb-3">
			<label class="form-label">Видимість</label>
			<select name="visibility" class="form-select">
				<option value="public" <?= $post['visibility'] === 'public' ? 'selected' : '' ?>>Для всіх</option>
				<option value="private" <?= $post['visibility'] === 'private' ? 'selected' : '' ?>>Тільки для авторизованих</option>
			</select>
		</div>

		<div class="form-check mb-3">
			<input class="form-check-input" type="checkbox" name="show_on_main" id="show_on_main" <?= $post['show_on_main'] ? 'checked' : '' ?>>
			<label class="form-check-label" for="show_on_main">
				Показувати на головній
			</label>
		</div>

		<div class="form-check mb-3">
			<input class="form-check-input" type="checkbox" name="draft" id="draft" <?= $post['draft'] ? 'checked' : '' ?>>
			<label class="form-check-label" for="draft">
				Зберегти як чернетку
			</label>
		</div>

		<button type="submit" class="btn btn-primary">
			💾 Зберегти зміни
		</button>
	</form>
</div>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
?>