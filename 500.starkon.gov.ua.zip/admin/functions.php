<?php
/**
 * Підключення до бази даних SQLite
 *
 * @param string $path Шлях до бази даних
 * @return PDO Підключення до бази
 */
function connectToDatabase($path = '/data/BD/database.sqlite') {
	try {
		$pdo = new PDO('sqlite:' . $_SERVER['DOCUMENT_ROOT'] . $path);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		return $pdo;
	} catch (PDOException $e) {
		die("Не вдалося підключитися до бази даних: " . $e->getMessage());
	}
}

/**
 * Перевірка, чи існує користувач
 *
 * @param PDO $pdo
 * @param string $username
 * @return bool
 */
function userExists($pdo, $username) {
	$stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = :login");
	$stmt->execute([':login' => $username]);
	return $stmt->fetchColumn() > 0;
}

/**
 * Створення нового користувача
 *
 * @param PDO $pdo
 * @param string $username
 * @param string $password
 * @param string $role
 */
function createUser($pdo, $username, $password, $role = 'user') {
	$passwordHash = password_hash($password, PASSWORD_BCRYPT);
	$stmt = $pdo->prepare("INSERT INTO users (login, password, role) VALUES (:login, :password, :role)");
	$stmt->execute([
		':login' => $username,
		':password' => $passwordHash,
		':role' => $role
	]);
}

/**
 * Отримання списку всіх користувачів
 *
 * @param PDO $pdo
 * @return array
 */
function getAllUsers($pdo) {
	$stmt = $pdo->query("SELECT id, login, role FROM users");
	return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Видалення користувача
 *
 * @param PDO $pdo
 * @param string $username
 */
function deleteUser($pdo, $username) {
	$stmt = $pdo->prepare("DELETE FROM users WHERE login = :login");
	$stmt->execute([':login' => $username]);
}

/**
 * Оновлення ролі та/або пароля користувача
 *
 * @param PDO $pdo
 * @param string $username
 * @param string|null $newPassword
 * @param string $newRole
 */
function updateUser($pdo, $username, $newPassword = null, $newRole = 'user') {
	if (!empty($newPassword)) {
		$newPasswordHash = password_hash($newPassword, PASSWORD_BCRYPT);
		$stmt = $pdo->prepare("UPDATE users SET password = :password, role = :role WHERE login = :login");
		$stmt->execute([
			':password' => $newPasswordHash,
			':role' => $newRole,
			':login' => $username
		]);
	} else {
		$stmt = $pdo->prepare("UPDATE users SET role = :role WHERE login = :login");
		$stmt->execute([
			':role' => $newRole,
			':login' => $username
		]);
	}
}
?>