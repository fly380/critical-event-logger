<?php
session_start();

require_once __DIR__ . '/../admin/functions.php';
// Підключення до БД через функцію
$pdo = connectToDatabase();
// Отримуємо мета-дані
$stmt = $pdo->query("SELECT key, value FROM settings");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
// Задаємо заголовок сторінки
$page_title = 'Головна адміністратора';
// Буферизація контенту
ob_start();
?>
<div class="col-md-9 col-lg-10 p-4">
	<h1 class="h3 mb-4">👋 Вітаємо в панелі адміністратора</h1>
	<div class="card mb-4">
		<div class="card-body">
			<h5 class="card-title">🧠 Про CMS</h5>
			<strong>Назва:</strong> <?= htmlspecialchars($settings['cms_name'] ?? 'CMS') ?><br />
			<strong>Версія:</strong> <?= htmlspecialchars($settings['cms_version'] ?? '1.0.0') ?><br />
			<strong>Автор:</strong> <?= htmlspecialchars($settings['site_author'] ?? 'невідомо') ?>
		</div>
	</div>
	<div class="card mb-4">
	<div class="card-body">
		<h5 class="card-title">📝 Список змін (Changelog)</h5>
		<div class="bg-light p-3 rounded">
			<?= $settings['cms_changelog'] ?? '<em>Немає даних...</em>' ?>
		</div>
	</div>
</div>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
