<?php
header("Location: /templates/login.php");
exit;
?>

