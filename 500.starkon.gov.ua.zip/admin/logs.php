<?php
// Показ усіх помилок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once __DIR__ . '/../admin/functions.php';
$logFile = $_SERVER['DOCUMENT_ROOT'] . '/data/logs/activity.log';
$message = '';

// Очистка логу, якщо була надіслана форма
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clearLogs'])) {
	if (file_exists($logFile)) {
		file_put_contents($logFile, ""); // Очищуємо файл
		$message = "Логи успішно очищено.";
	} else {
		$message = "Файл логів не знайдено.";
	}
}

$logs = file_exists($logFile) ? file($logFile, FILE_IGNORE_NEW_LINES) : [];
$current_page = basename($_SERVER['PHP_SELF']);

// Буферизація контенту
ob_start();
?>

		<style>
	.btn.active {
		background-color: #0d6efd;
		color: white;
		border-color: #0d6efd;
	}
</style>
		<!-- Основний контент -->		 
   <h1 class="h4 mb-4">Журнал дій</h1>
	  <!-- Повідомлення про успішну очистку -->
	<?php if (isset($message)): ?>
		<div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
	<?php endif; ?>

	<pre id="log-output" class="bg-light p-3 border rounded" style="max-height: 500px; overflow-y: scroll;">
Завантаження логів...
</pre>

<script>
function fetchLogs() {
	fetch('logs_fetch.php')
		.then(response => response.text())
		.then(data => {
			document.getElementById('log-output').textContent = data;
		})
		.catch(err => {
			document.getElementById('log-output').textContent = "Помилка при завантаженні логів.";
			console.error(err);
		});
}

// Завантажити логи одразу і оновлювати кожні 10 секунд
fetchLogs();
setInterval(fetchLogs, 10000);
</script>

	<!-- Кнопка для очищення логів --> <form action="logs.php" method="POST">
		<button type="submit" name="clearLogs" class="btn btn-danger mb-3">Очистити логи</button>
	</form>
<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';