<?php
// admin/media.php
session_start();
require_once __DIR__ . '/../admin/functions.php';
require_once __DIR__ . '/../plugins/ukr_to_lat.php';
require_once __DIR__ . '/../data/log_action.php';

// === Налаштування ===
$uploadBaseDir = __DIR__ . '/../uploads';
$excludeDir = realpath($uploadBaseDir . '/cms_img');
$baseUrl = '/uploads';
$message = '';

$username = $_SESSION['username'] ?? 'невідомо';

// Функція для зменшення зображення
function resizeImage($sourcePath, $targetPath, $maxWidth = 1200, $quality = 85) {
    // Отримуємо інформацію про зображення
    list($width, $height, $type) = getimagesize($sourcePath);
    
    // Якщо ширина вже менша за максимальну, просто копіюємо
    if ($width <= $maxWidth) {
        return copy($sourcePath, $targetPath);
    }
    
    // Обчислюємо нову висоту пропорційно
    $newWidth = $maxWidth;
    $newHeight = floor($height * ($maxWidth / $width));
    
    // Створюємо нове зображення
    $src = null;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $src = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $src = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_GIF:
            $src = imagecreatefromgif($sourcePath);
            break;
        case IMAGETYPE_WEBP:
            if (function_exists('imagecreatefromwebp')) {
                $src = imagecreatefromwebp($sourcePath);
            }
            break;
        default:
            return false;
    }
    
    if (!$src) return false;
    
    // Створюємо нове зображення з потрібними розмірами
    $dst = imagecreatetruecolor($newWidth, $newHeight);
    
    // Зберігаємо прозорість для PNG
    if ($type === IMAGETYPE_PNG) {
        imagealphablending($dst, false);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 255, 255, 255, 127);
        imagefilledrectangle($dst, 0, 0, $newWidth, $newHeight, $transparent);
    }
    
    // Змінюємо розмір
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    
    // Зберігаємо результат
    $result = false;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $result = imagejpeg($dst, $targetPath, $quality);
            break;
        case IMAGETYPE_PNG:
            $quality = floor($quality / 10); // Для PNG якість від 0 до 9
            $result = imagepng($dst, $targetPath, $quality);
            break;
        case IMAGETYPE_GIF:
            $result = imagegif($dst, $targetPath);
            break;
        case IMAGETYPE_WEBP:
            if (function_exists('imagewebp')) {
                $result = imagewebp($dst, $targetPath, $quality);
            }
            break;
    }
    
    // Очищаємо пам'ять
    imagedestroy($src);
    imagedestroy($dst);
    
    return $result;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['media'])) {
    $year = date('Y');
    $month = date('m');
    $uploadDir = "$uploadBaseDir/$year/$month";
    $uploadUrl = "$baseUrl/$year/$month";

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $file = $_FILES['media'];
    if ($file['error'] === UPLOAD_ERR_OK) {
        $originalName = basename($file['name']);
        $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        $baseName = pathinfo($originalName, PATHINFO_FILENAME);

        // 🔤 Транслітерація
        $safeName = ctl_transliterate($baseName);
        $safeName = preg_replace('/[^a-zA-Z0-9_-]/', '-', $safeName);
        $safeName = preg_replace('/-+/', '-', $safeName);
        $safeName = trim($safeName, '-');
        $safeName = substr($safeName, 0, 50);
        if (empty($safeName)) $safeName = 'file';

        // 💾 Перевірка дублікатів і створення унікального імені
        do {
            $hash = substr(sha1(uniqid(mt_rand(), true)), 0, 6);
            $finalName = $safeName . '-' . $hash . '.' . $extension;
            $targetPath = "$uploadDir/$finalName";
        } while (file_exists($targetPath));

        // Спочатку зберігаємо тимчасовий файл
        $tempPath = "$uploadDir/temp_$finalName";
        if (move_uploaded_file($file['tmp_name'], $tempPath)) {
            
            // Якщо це зображення - зменшуємо його
            $imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            if (in_array($extension, $imageExtensions)) {
                // Зменшуємо зображення до 1200px ширини
                if (resizeImage($tempPath, $targetPath, 1200, 85)) {
                    unlink($tempPath); // Видаляємо тимчасовий файл
                    log_action("📁 Завантажено та зменшено зображення '{$originalName}' → '{$finalName}'", $username);
                } else {
                    // Якщо не вдалося зменшити, використовуємо оригінал
                    rename($tempPath, $targetPath);
                    log_action("📁 Завантажено файл (без зменшення) '{$originalName}' → '{$finalName}'", $username);
                }
            } else {
                // Для не-зображень просто перейменовуємо
                rename($tempPath, $targetPath);
                log_action("📁 Завантажено файл '{$originalName}' → '{$finalName}'", $username);
            }
            
            header("Location: media.php?uploaded=1");
            exit;
        } else {
            $message = '❌ Помилка при збереженні файлу.';
        }
    } else {
        $message = '❌ Файл не було завантажено.';
    }
}

// === Перейменування файлу (AJAX) ===
if (isset($_POST['rename_file']) && isset($_POST['new_name'])) {
    $oldPath = realpath(__DIR__ . '/../' . ltrim($_POST['rename_file'], '/\\'));
    $newName = basename($_POST['new_name']);
    $newPath = dirname($oldPath) . '/' . $newName;

    if ($oldPath && strpos($oldPath, realpath($uploadBaseDir)) === 0 && strpos($oldPath, $excludeDir) === false) {
        if (rename($oldPath, $newPath)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
    }
    exit;
}

function getAllMediaFiles($dir, $excludeDir)
{
    $files = [];
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)
    );

    foreach ($iterator as $fileInfo) {
        if ($fileInfo->isFile()) {
            $realPath = $fileInfo->getRealPath();
            if (strpos($realPath, $excludeDir) === false) {
                $relativePath = str_replace(realpath(__DIR__ . '/../'), '', $realPath);
                $files[] = [
                    'path' => $relativePath,
                    'name' => $fileInfo->getFilename(),
                    'url' => '/' . ltrim(str_replace('\\', '/', $relativePath), '/')
                ];
            }
        }
    }
    return $files;
}

$mediaFiles = getAllMediaFiles($uploadBaseDir, $excludeDir);

// ВИПРАВЛЕНО: замінено стрілкову функцію на звичайну для PHP 7.2
usort($mediaFiles, function($a, $b) {
    return strcmp($a['name'], $b['name']);
});

// Обробка фільтра та сортування
$filter = $_GET['filter'] ?? 'all';
$sort = $_GET['sort'] ?? 'newest';

// ВИПРАВЛЕНО: замінено стрілкові функції на звичайні для PHP 7.2
if ($filter === 'images') {
    $mediaFiles = array_filter($mediaFiles, function($f) {
        return preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f['name']);
    });
} elseif ($filter === 'others') {
    $mediaFiles = array_filter($mediaFiles, function($f) {
        return !preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f['name']);
    });
}

if ($sort === 'newest' || $sort === 'az') {
    usort($mediaFiles, function($a, $b) {
        return strcmp($a['name'], $b['name']);
    });
} elseif ($sort === 'za') {
    usort($mediaFiles, function($a, $b) {
        return strcmp($b['name'], $a['name']);
    });
}

// Обробка AJAX-запиту на видалення
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_file') {
    $fileToDelete = realpath(__DIR__ . '/../' . ltrim($_POST['file'], '/\\'));

    // Перевірка, що файл всередині uploads і не в cms_img
    $uploadsBase = realpath(__DIR__ . '/../uploads');
    $cmsImgPath = realpath(__DIR__ . '/../uploads/cms_img');

    if (strpos($fileToDelete, $uploadsBase) === 0 && strpos($fileToDelete, $cmsImgPath) !== 0 && file_exists($fileToDelete)) {
        if (unlink($fileToDelete)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Не вдалося видалити файл.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Недійсний файл.']);
    }
    exit;
}

ob_start();
?>
<!-- Bootstrap Modal -->
<div class="modal fade" id="previewModal" tabindex="-1" aria-labelledby="previewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="previewModalLabel">Попередній перегляд</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Закрити"></button>
      </div>
      <div class="modal-body text-center" id="previewContent">
        <p>Завантаження...</p>
      </div>
    </div>
  </div>
</div>

<!-- Modal для перегляду зображень -->
<div class="modal fade" id="mediaModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-body text-center">
                <img src="" class="img-fluid" id="modalImage">
            </div>
        </div>
    </div>
</div>

<div class="container mt-4">
    <h1 class="h4">Медіа бібліотека</h1>

    <?php if (!empty($message)): ?>
        <div class="alert alert-warning"><?= $message ?></div>
    <?php elseif (!empty($_GET['uploaded'])): ?>
        <div class="alert alert-success">✅ Файл завантажено та оптимізовано!</div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="mb-3">
        <div class="input-group">
            <input type="file" name="media" class="form-control" required>
            <button class="btn btn-primary" type="submit">Завантажити та оптимізувати</button>
        </div>
        <small class="text-muted">Зображення автоматично зменшуються до 1200px ширини для економії місця</small>
    </form>
    
    <div class="row mb-3">
        <div class="col-md-6">
            <select class="form-select" onchange="location.href='?filter=' + this.value + '&sort=<?= $sort ?>'">
                <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Усі файли</option>
                <option value="images" <?= $filter === 'images' ? 'selected' : '' ?>>Тільки зображення</option>
                <option value="others" <?= $filter === 'others' ? 'selected' : '' ?>>Інші файли</option>
            </select>
        </div>
        <div class="col-md-6">
            <select class="form-select" onchange="location.href='?sort=' + this.value + '&filter=<?= $filter ?>'">
                <option value="az" <?= $sort === 'az' ? 'selected' : '' ?>>За назвою A-Z</option>
                <option value="za" <?= $sort === 'za' ? 'selected' : '' ?>>За назвою Z-A</option>
            </select>
        </div>
    </div>

    <?php if (!empty($mediaFiles)): ?>
        <div class="list-group" id="mediaList">
            <?php foreach ($mediaFiles as $file): ?>
                <div class="list-group-item d-flex gap-3 align-items-start">
                    <?php if (preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $file['name'])): ?>
                        <img src="<?= htmlspecialchars($file['url']) ?>" class="border rounded" style="width:80px; height:80px; object-fit:cover; cursor:pointer" onclick="showModal('<?= htmlspecialchars($file['url']) ?>')">
                    <?php else: ?>
                        <div class="border rounded bg-light d-flex align-items-center justify-content-center" style="width:80px; height:80px;">
                            <span class="text-muted">📄</span>
                        </div>
                    <?php endif; ?>
                    <div class="flex-fill">
                        <input class="form-control form-control-sm mb-2 filename-input" value="<?= htmlspecialchars($file['name']) ?>" data-path="<?= htmlspecialchars($file['path']) ?>">
                        <div class="small">
                            <a href="#" onclick="renameFile(this); return false;">✏️ Редагувати</a> |
                            <a href="#" class="media-delete-link text-danger" data-file="<?= htmlspecialchars($file['url']) ?>">🗑️ Видалити</a> |
                            <a href="#" class="media-preview-link" data-url="<?= htmlspecialchars($file['url']) ?>">👁️ Переглянути</a> |
                            <a href="#" onclick="copyToClipboard('<?= htmlspecialchars($file['url']) ?>'); return false;">📋 Копіювати URL</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="alert alert-info">📁 Файли відсутні. Завантажте перший файл.</div>
    <?php endif; ?>
</div>

<script>
function showModal(url) {
    const modal = new bootstrap.Modal(document.getElementById('mediaModal'));
    document.getElementById('modalImage').src = url;
    modal.show();
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('URL скопійовано!');
    }, function() {
        alert('Помилка копіювання');
    });
}

function renameFile(link) {
    const input = link.closest('.list-group-item').querySelector('.filename-input');
    const newName = prompt('Нова назва файлу:', input.value);
    if (!newName) return;
    
    const formData = new URLSearchParams();
    formData.append('rename_file', input.dataset.path);
    formData.append('new_name', newName);
    
    fetch('media.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: formData.toString()
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            input.value = newName;
            alert('✅ Файл перейменовано');
        } else {
            alert('❌ Помилка перейменування');
        }
    })
    .catch(error => {
        alert('❌ Помилка: ' + error.message);
    });
}

// Обробка видалення
document.querySelectorAll('.media-delete-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const file = this.dataset.file;
        if (!confirm("🗑️ Видалити цей файл?\nЦю дію не можна скасувати!")) return;

        const formData = new URLSearchParams();
        formData.append('action', 'delete_file');
        formData.append('file', file);

        fetch('media.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: formData.toString()
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                this.closest('.list-group-item').remove();
                alert('✅ Файл видалено');
            } else {
                alert('❌ ' + (data.error || 'Помилка видалення'));
            }
        })
        .catch(error => {
            alert('❌ Помилка: ' + error.message);
        });
    });
});

// Обробка попереднього перегляду
document.querySelectorAll('.media-preview-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const url = this.dataset.url;
        const ext = url.split('.').pop().toLowerCase();
        const modalBody = document.getElementById('previewContent');
        const modalTitle = document.getElementById('previewModalLabel');

        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
            modalTitle.textContent = 'Перегляд зображення';
            modalBody.innerHTML = `<img src="${url}" class="img-fluid rounded" alt="Зображення" style="max-height:70vh;">`;
        } else if (['mp4', 'webm', 'ogg'].includes(ext)) {
            modalTitle.textContent = 'Перегляд відео';
            modalBody.innerHTML = `<video src="${url}" controls class="img-fluid rounded" style="max-height:70vh;"></video>`;
        } else if (ext === 'pdf') {
            modalTitle.textContent = 'Перегляд PDF';
            modalBody.innerHTML = `<iframe src="${url}" style="width:100%; height:70vh;" frameborder="0"></iframe>`;
        } else {
            modalTitle.textContent = 'Інформація про файл';
            modalBody.innerHTML = `<p>Файл: ${url.split('/').pop()}</p>
                                  <p>Тип: ${ext.toUpperCase()}</p>
                                  <p><a href="${url}" target="_blank" class="btn btn-primary">Відкрити в новій вкладці</a></p>`;
        }

        const modal = new bootstrap.Modal(document.getElementById('previewModal'));
        modal.show();
    });
});
</script>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
?>