<?php
session_start();

$uploadsDir = realpath(__DIR__ . '/../uploads');
$excludeDir = realpath($uploadsDir . '/cms_img');
$images = [];

// Рекурсивно шукаємо зображення
$iterator = new RecursiveIteratorIterator(
	new RecursiveDirectoryIterator($uploadsDir, RecursiveDirectoryIterator::SKIP_DOTS)
);

foreach ($iterator as $fileInfo) {
	$path = $fileInfo->getRealPath();

	if (
		$fileInfo->isFile() &&
		preg_match('/\.(jpe?g|png|gif|webp)$/i', $fileInfo->getFilename()) &&
		strpos($path, $excludeDir) !== 0
	) {
		$relPath = str_replace(realpath(__DIR__ . '/../'), '', $path);
		$webPath = '/' . ltrim(str_replace('\\', '/', $relPath), '/');
		$images[] = $webPath;
	}
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
	<meta charset="UTF-8">
	<title>Вибір зображення</title>
	<style>
		body { font-family: sans-serif; padding: 10px; }
		h3 { margin-bottom: 1rem; }
		.grid { display: flex; flex-wrap: wrap; gap: 10px; }
		img {
			width: 150px; height: auto; border: 1px solid #ccc;
			cursor: pointer; border-radius: 4px;
			transition: transform 0.2s;
		}
		img:hover { transform: scale(1.05); border-color: #007bff; }
	</style>
</head>
<body>
	<h3>Оберіть зображення</h3>
	<div class="grid">
	<?php foreach ($images as $img): ?>
		<img src="<?= htmlspecialchars($img) ?>" onclick="selectImage('<?= htmlspecialchars($img) ?>')">
	<?php endforeach; ?>
	</div>

	<script>
	function selectImage(url) {
		if (window.opener && window.opener.tinymceImageCallback) {
			window.opener.tinymceImageCallback(url, { alt: '' });
			window.close();
		}
	}
	</script>
</body>
</html>
