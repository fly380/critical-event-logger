<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/../admin/functions.php';
require_once __DIR__ . '/../data/log_action.php';

$db = new PDO('sqlite:' . __DIR__ . '/../data/BD/database.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Перевірка, чи існує колонка visibility_role
$query = $db->query("PRAGMA table_info(menu_items)");
$columns = $query->fetchAll(PDO::FETCH_ASSOC);
$columnExists = false;
foreach ($columns as $column) {
	if ($column['name'] === 'visibility_role') {
		$columnExists = true;
		break;
	}
}
if (!$columnExists) {
	$db->exec("ALTER TABLE menu_items ADD COLUMN visibility_role TEXT DEFAULT 'all'");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	if (isset($_POST['menu']) && is_array($_POST['menu'])) {
		$position = 1;
		// Видалення пунктів меню
		if (!empty($_POST['delete_ids']) && is_array($_POST['delete_ids'])) {
			$placeholders = implode(',', array_fill(0, count($_POST['delete_ids']), '?'));
			$stmt = $db->prepare("DELETE FROM menu_items WHERE id IN ($placeholders)");
			$stmt->execute($_POST['delete_ids']);
		}

		foreach ($_POST['menu'] as $item) {
			if (!isset($item['type'])) {
				continue;
			}
			$title = trim($item['title'] ?? '');
			$url = $item['url'] ?? '';
			$type = $item['type'];
			if ($type === 'login_logout' && $title === '') {
				$title = 'Вхід/Вихід';
			}
			if ($title === '') {
				continue;
			}
			$visible = !empty($item['visible']) ? 1 : 0;
			$auth_only = !empty($item['auth_only']) ? 1 : 0;
			$visibility_role = $item['visibility_role'] ?? 'all';
			$parent_id = is_numeric($item['parent_id'] ?? null) ? (int)$item['parent_id'] : null;


			if (!empty($item['id'])) {
				// Оновлення існуючого пункту меню
				$stmt = $db->prepare("UPDATE menu_items SET title = ?, url = ?, position = ?, visible = ?, auth_only = ?, type = ?, visibility_role = ?, parent_id = ? WHERE id = ?");
				$stmt->execute([
				$title, $url, $position,
				$visible, $auth_only, $type, $visibility_role, $parent_id, $item['id']
				]);
			} else {
				// Додавання нового пункту меню
				$stmt = $db->prepare("INSERT INTO menu_items (title, url, position, visible, auth_only, type, visibility_role, parent_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
				$stmt->execute([
				$title, $url, $position,
				$visible, $auth_only, $type, $visibility_role, $parent_id
				]);
			}
			$position++;
		}
	}
	log_action("🔧 Оновлено меню", $_SESSION['username']);
	header("Location: menu_editor.php?saved=1");
	exit;
}

// Завантаження меню
$menu = $db->query("SELECT * FROM menu_items ORDER BY position ASC")->fetchAll(PDO::FETCH_ASSOC);
$current_page = basename($_SERVER['PHP_SELF']);

// Отримання списку сторінок та записів
$dbPages = $db->query("SELECT slug, title FROM pages WHERE draft = 0 ORDER BY title")->fetchAll(PDO::FETCH_ASSOC);
$dbPosts = $db->query("SELECT slug, meta_title as title FROM posts WHERE draft = 0 ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

$filePages = [];
$directory = __DIR__ . '/../';
$files = glob($directory . '*.php');
foreach ($files as $filePath) {
	$filename = basename($filePath);
	if (strpos($filename, 'admin') === 0) continue; // пропускаємо адмінські файли
	$filePages[] = [
		'slug' => $filename,
		'title' => ucfirst(str_replace(['.php', '_'], ['', ' '], $filename)) . ' (файл)'
	];
}

$pages = array_merge($dbPages, $dbPosts, $filePages);

// Заголовок сторінки
$page_title = 'Редактор меню';

// Буферизація контенту
ob_start();
?>
	<style>
		.menu-row { border-bottom: 1px solid #ccc; padding: 10px 0; cursor: move; }
		.menu-row input, .menu-row select { margin-right: 10px; }
		.dragging { opacity: 0.5; }
	.btn.active {
		background-color: #0d6efd;
		color: white;
		border-color: #0d6efd;
	}
	.drag-over {
	border: 2px dashed #007bff;
	background-color: #e9f5ff;
}

</style>
<datalist id="pagesList">
	<?php foreach ($pages as $page): ?>
		<option value="/<?= htmlspecialchars($page['slug']) ?>">
			<?= htmlspecialchars($page['title']) ?>
		</option>
	<?php endforeach; ?>
</datalist>
		<div class="col-md-9 col-lg-10 p-4">
			<div class="container py-4">
				<h2 class="mb-4">Редактор меню</h2>
				<form method="POST">
					<div id="menuItems">
						<?php foreach ($menu as $index => $item): ?>
						<div class="menu-row d-flex align-items-center flex-wrap" draggable="true">
							<input type="hidden" name="menu[<?= $index ?>][id]" value="<?= $item['id'] ?>">
							<input type="text" name="menu[<?= $index ?>][title]" class="form-control form-control-sm mb-2" style="width: 150px;" placeholder="Назва" value="<?= htmlspecialchars($item['title']) ?>">						   
							<input type="text" name="menu[<?= $index ?>][url]" class="form-control form-control-sm mb-2" style="width: 200px;" placeholder="URL" list="pagesList" value="<?= htmlspecialchars($item['url']) ?>">
							<select name="menu[<?= $index ?>][type]" class="form-select form-select-sm mb-2" style="width: 140px;">
								<option value="link" <?= $item['type'] === 'link' ? 'selected' : '' ?>>Посилання</option>
								<option value="login_logout" <?= $item['type'] === 'login_logout' ? 'selected' : '' ?>>Вхід/Вихід</option>
							</select>
							<select name="menu[<?= $index ?>][parent_id]" class="form-select form-select-sm mb-2" style="width: 160px;">
	<option value="">— Головне меню —</option>
	<?php foreach ($menu as $parent): ?>
		<?php if ($parent['id'] != $item['id']): ?>
			<option value="<?= $parent['id'] ?>" <?= $item['parent_id'] == $parent['id'] ? 'selected' : '' ?>>
				<?= htmlspecialchars($parent['title']) ?>
			</option>
		<?php endif; ?>
	<?php endforeach; ?>
</select>

							<select name="menu[<?= $index ?>][visibility_role]" class="form-select form-select-sm mb-2" style="width: 160px;">
							<option value="all" <?= $item['visibility_role'] === 'all' ? 'selected' : '' ?>>Усі</option>
							<option value="editor_admin" <?= $item['visibility_role'] === 'editor_admin' ? 'selected' : '' ?>>Редактор + Адмін</option>
							<option value="admin" <?= $item['visibility_role'] === 'admin' ? 'selected' : '' ?>>Тільки адмін</option>
							</select>
							<div class="form-check mb-2 ms-2">
								<input class="form-check-input" type="checkbox" name="menu[<?= $index ?>][visible]" value="1" <?= $item['visible'] ? 'checked' : '' ?>>
								<label class="form-check-label">Видимий</label>
							</div>
							<div class="form-check mb-2 ms-2">
								<input class="form-check-input" type="checkbox" name="menu[<?= $index ?>][auth_only]" value="1" <?= $item['auth_only'] ? 'checked' : '' ?>>
								<label class="form-check-label">Авториз.</label>
							</div>
							<button type="button" class="btn btn-sm btn-outline-danger ms-2 mb-2" onclick="removeMenuItem(this)">🗑</button>
						</div>
						<?php endforeach; ?>
					</div>
					<button type="button" class="btn btn-secondary mt-3" onclick="addMenuItem()">➕ Додати пункт</button><br>
					<button type="submit" class="btn btn-primary mt-3">💾 Зберегти меню</button>
				</form>
			</div>
		</div>
	</div>
</div>

<script>
function generateUniqueKey() {
	return 'k' + Date.now() + Math.floor(Math.random() * 1000);
}
function addMenuItem() {
	const key = generateUniqueKey();
	const container = document.getElementById('menuItems');
	const div = document.createElement('div');
	div.className = 'menu-row d-flex align-items-center flex-wrap';
	div.setAttribute('draggable', true);
	div.innerHTML = `
		<input type="text" name="menu[${key}][title]" class="form-control form-control-sm mb-2" style="width: 150px;" placeholder="Назва">
		<input type="text" name="menu[${key}][url]" class="form-control form-control-sm mb-2" style="width: 200px;" placeholder="URL" list="pagesList">
		<select name="menu[${key}][type]" class="form-select form-select-sm mb-2" style="width: 140px;">
			<option value="link">Посилання</option>
			<option value="login_logout">Вхід/Вихід</option>
		</select>
		<select name="menu[${key}][visibility_role]" class="form-select form-select-sm mb-2" style="width: 160px;">
			<option value="all">Усі</option>
			<option value="editor_admin">Редактор + Адмін</option>
			<option value="admin">Тільки адмін</option>
		</select>
		<div class="form-check mb-2 ms-2">
			<input class="form-check-input" type="checkbox" name="menu[${key}][visible]" value="1">
			<label class="form-check-label">Видимий</label>
		</div>
		<div class="form-check mb-2 ms-2">
			<input class="form-check-input" type="checkbox" name="menu[${key}][auth_only]" value="1">
			<label class="form-check-label">Авториз.</label>
		</div>
		<button type="button" class="btn btn-sm btn-outline-danger ms-2 mb-2" onclick="removeMenuItem(this)">🗑</button>
	`;
	container.appendChild(div);
	makeDraggable(div);
}
function removeMenuItem(btn) {
	const row = btn.closest('.menu-row');
	if (row) {
		const hiddenId = row.querySelector('input[name$="[id]"]');
		if (hiddenId) {
			const deleteInput = document.createElement('input');
			deleteInput.type = 'hidden';
			deleteInput.name = 'delete_ids[]';
			deleteInput.value = hiddenId.value;
			document.querySelector('form').appendChild(deleteInput);
		}
		row.remove();
	}
}
</script>

<script>
function makeDraggable(element) {
	element.addEventListener('dragstart', (e) => {
		element.classList.add('dragging');
	});

	element.addEventListener('dragend', (e) => {
		element.classList.remove('dragging');
	});

	element.addEventListener('dragover', (e) => {
		e.preventDefault();
	});

	element.addEventListener('drop', (e) => {
		e.preventDefault();
		const dragging = document.querySelector('.dragging');
		if (dragging && dragging !== element) {
			const container = document.getElementById('menuItems');
			container.insertBefore(dragging, element.nextSibling);
		}
	});

	element.addEventListener('dragenter', (e) => {
		e.preventDefault();
		element.classList.add('drag-over');
	});

	element.addEventListener('dragleave', (e) => {
		element.classList.remove('drag-over');
	});
}

document.querySelectorAll('.menu-row').forEach(makeDraggable);

// Перед сабмітом оновлюємо `name` атрибути
document.querySelector('form').addEventListener('submit', function () {
	const rows = document.querySelectorAll('#menuItems .menu-row');
	rows.forEach((row, index) => {
		const inputs = row.querySelectorAll('input, select');
		inputs.forEach(input => {
			const name = input.getAttribute('name');
			if (name) {
				const newName = name.replace(/menu\[[^\]]+\]/, `menu[${index}]`);
				input.setAttribute('name', newName);
			}
		});
	});
});
</script>
<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';