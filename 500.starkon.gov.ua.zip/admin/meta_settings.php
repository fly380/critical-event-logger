<?php
session_start();

require_once __DIR__ . '/../admin/functions.php';

$db = new PDO('sqlite:' . __DIR__ . '/../data/BD/database.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$success = false;

// Отримуємо поточні значення
$stmt = $db->query("SELECT key, value FROM settings");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$fields = ['site_author', 'cms_name', 'cms_version', 'cms_changelog'];
	foreach ($fields as $field) {
		$value = trim($_POST[$field] ?? '');
		$stmt = $db->prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
		$stmt->execute([$field, $value]);
	}
	header("Location: meta_settings.php?success=1");
	exit;
}

$page_title = 'Сторінка налаштувань адмінки';

ob_start();
?>

<script src="/assets/tinymce/tinymce.min.js"></script>
<script>
tinymce.init({
	selector: 'textarea',
	language_url: '/assets/tinymce/langs/uk.js',
	language: 'uk',
	license_key: 'off',
	height: 400,
	toolbar_mode: 'wrap',
	plugins: [ 'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
			   'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
			   'insertdatetime', 'media', 'table', 'code', 'help', 'wordcount', 'emoticons' ],
	toolbar: 'aihelper | undo redo | styles | bold italic underline | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media table preview code fullscreen | help',
	setup: function (editor) {
		editor.ui.registry.addButton('aihelper', {
			text: '🤖 ШІ-помічник',
			onAction: function () {
	const userPrompt = prompt("Введіть запит для генерації (наприклад: згенеруй текст про нашу компанію):");
	if (userPrompt) {
		fetch('ai_helper.php', {
	method: 'POST',
	headers: { 'Content-Type': 'application/json' },
	body: JSON.stringify({ prompt: userPrompt })
})
.then(res => res.text()) // ⬅️ тимчасово отримуємо текст, а не .json()
.then(text => {
	console.log("RAW response:", text); // подивимось, що саме повертається
	try {
		const data = JSON.parse(text);
		if (data.text) {
			editor.insertContent(data.text);
		} else {
			alert("Помилка генерації");
		}
	} catch (e) {
		console.error("JSON parse error:", e);
		alert("Сервер повернув некоректну відповідь. Перевірте ai_helper.php.");
	}
});

	}
}

		});
	},
	content_style: 'body { font-family:Arial,sans-serif; font-size:14px }'
});
</script>
<div class="container">
	<h2 class="mb-4"> Налаштування даних CMS</h2>

	<?php if (isset($_GET['success'])): ?>
		<div class="alert alert-success">✅ Зміни збережено успішно!</div>
	<?php endif; ?>

	<form method="post" class="bg-white p-4 rounded shadow-sm">
		<div class="mb-3">
			<label for="site_author" class="form-label">Автор сайту</label>
			<input type="text" id="site_author" name="site_author" class="form-control" value="<?= htmlspecialchars($settings['site_author'] ?? '') ?>">
		</div>

		<div class="mb-3">
			<label for="cms_name" class="form-label">Назва CMS</label>
			<input type="text" id="cms_name" name="cms_name" class="form-control" value="<?= htmlspecialchars($settings['cms_name'] ?? '') ?>">
		</div>

		<div class="mb-3">
			<label for="cms_version" class="form-label">Версія CMS</label>
			<input type="text" id="cms_version" name="cms_version" class="form-control" value="<?= htmlspecialchars($settings['cms_version'] ?? '') ?>">
		</div>

		<div class="mb-3">
			<label for="cms_changelog" class="form-label">Опис змін (Changelog)</label>
			<textarea id="cms_changelog" name="cms_changelog" class="form-control" rows="6"><?= htmlspecialchars($settings['cms_changelog'] ?? '') ?></textarea>
		</div>
		
		<button type="submit" class="btn btn-primary">💾 Зберегти</button>
	</form>
</div>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';