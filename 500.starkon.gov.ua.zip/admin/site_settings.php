<?php
// Показ усіх помилок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
// Перевірка авторизації
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
	header("Location: /templates/login.php");
	exit;
}

$db = new PDO('sqlite:' . __DIR__ . '/../data/BD/database.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

function save_setting($db, $key, $value) {
	$stmt = $db->prepare("SELECT COUNT(*) FROM settings WHERE key = :key");
	$stmt->execute([':key' => $key]);
	$exists = $stmt->fetchColumn();

	if ($exists) {
		$stmt = $db->prepare("UPDATE settings SET value = :value WHERE key = :key");
	} else {
		$stmt = $db->prepare("INSERT INTO settings (key, value) VALUES (:key, :value)");
	}
	$stmt->execute([':key' => $key, ':value' => $value]);
}

// Функція для видалення налаштувань
function delete_setting($db, $key) {
	$stmt = $db->prepare("DELETE FROM settings WHERE key = :key");
	$stmt->execute([':key' => $key]);
}

// Обробка видалення файлу
if (isset($_GET['delete']) && in_array($_GET['delete'], ['logo_path', 'favicon_path', 'background_image', 'hero_banner'])) {
	$key = $_GET['delete'];
	$stmt = $db->prepare("SELECT value FROM settings WHERE key = :key");
	$stmt->execute([':key' => $key]);
	$path = $stmt->fetchColumn();
	if ($path && file_exists(__DIR__ . $path)) {
		unlink(__DIR__ . $path);
	}
	delete_setting($db, $key);
	header("Location: site_settings.php?success=1");
	exit;
}

// Обробка форми при POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	// Збереження текстових налаштувань
	$fields = [
		'site_title', 'meta_description', 'meta_keywords', 'footer_text', 'admin_email',
		'phone_number', 'address',
		'hero_banner_link' // Видалено всі recaptcha поля
	];
	foreach ($fields as $field) {
		$value = $_POST[$field] ?? '';
		save_setting($db, $field, $value);
	}

	// Обробка завантаження файлів
	$img = [
		'logo_path' => 'logo',
		'favicon_path' => 'favicon',
		'background_image' => 'background',
		'hero_banner' => 'banner'
	];

	foreach ($img as $key => $prefix) {
		$existingFile = $_POST["existing_$key"] ?? '';
		
		// Спочатку перевіряємо, чи було завантажено новий файл
		if (!empty($_FILES[$key]['tmp_name']) && is_uploaded_file($_FILES[$key]['tmp_name'])) {
			$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml', 'image/x-icon'];
			$maxSize = 5 * 1024 * 1024;

			$tmpPath = $_FILES[$key]['tmp_name'];
			$mime = mime_content_type($tmpPath);
			$size = filesize($tmpPath);

			if (!in_array($mime, $allowedMimeTypes)) {
				die("❌ Недопустимий тип файлу для {$key}. Допустимі: JPG, PNG, GIF, WEBP, SVG, ICO.");
			}

			if ($size > $maxSize) {
				die("❌ Файл для {$key} перевищує максимально допустимий розмір 5 МБ.");
			}

			$ext = pathinfo($_FILES[$key]['name'], PATHINFO_EXTENSION);
			$fileName = $prefix . '_' . time() . '.' . $ext;
			$relativePath = 'uploads/cms_img/' . $fileName;
			$absolutePath = __DIR__ . '/../' . $relativePath;

			if (move_uploaded_file($tmpPath, $absolutePath)) {
				save_setting($db, $key, '/' . $relativePath);
			}
		}
		// Якщо вибрано "— Не обрано —" (порожнє значення) - видаляємо налаштування
		elseif ($existingFile === '') {
			// Видаляємо налаштування з бази даних
			delete_setting($db, $key);
		}
		// Якщо вибрано існуючий файл
		elseif (!empty($existingFile) && file_exists(__DIR__ . '/../uploads/cms_img/' . $existingFile)) {
			save_setting($db, $key, '/uploads/cms_img/' . $existingFile);
		}
		// Якщо не вибрано жодного файлу - залишаємо як є
	}

	header('Location: site_settings.php?success=1');
	exit;
}

// Отримання всіх налаштувань
$stmt = $db->query("SELECT key, value FROM settings");
$settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

function get_setting_val($key) {
	global $settings;
	return htmlspecialchars($settings[$key] ?? '');
}

function has_file($key) {
	global $settings;
	return isset($settings[$key]) && file_exists(__DIR__ . $settings[$key]);
}

function get_file_url($key) {
	global $settings;
	return $settings[$key] ?? '';
}
// Задаємо заголовок сторінки
$page_title = 'Налаштування сайту';

// Створюємо контент через буфер виводу
ob_start();
?>
	 <style>
		body { background-color: #f7f9fc; }
		.form-section { background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.05); }
		.form-section h3 { border-bottom: 1px solid #ddd; padding-bottom: 10px; margin-bottom: 20px; }
		.preview-img { max-height: 60px; margin-top: 10px; border: 1px solid #ccc; border-radius: 5px; }
		.banner-preview { max-height: 150px; width: auto; margin-top: 10px; border: 1px solid #ccc; border-radius: 5px; }
		.help-text { font-size: 0.875rem; color: #6c757d; margin-top: 0.25rem; }
	</style>
	
	<!-- Основний контент -->
	<div class="form-section">
		<h3>Налаштування сайту</h3>

		<?php if (isset($_GET['success'])): ?>
			<div class="alert alert-success">Налаштування збережено.</div>
		<?php endif; ?>

		<form method="post" enctype="multipart/form-data">
			<div class="row g-3 mb-4">
				<div class="col-md-6">
					<label for="site_title" class="form-label">Назва сайту</label>
					<input type="text" class="form-control" id="site_title" name="site_title" value="<?= get_setting_val('site_title') ?>">
				</div>
				<div class="col-md-6">
					<label for="footer_text" class="form-label">Текст футера</label>
					<input type="text" class="form-control" id="footer_text" name="footer_text" value="<?= get_setting_val('footer_text') ?>">
				</div>
			</div>
			
			<div class="mb-3">
				<label for="admin_email" class="form-label">Email адміністратора</label>
				<input type="email" class="form-control" id="admin_email" name="admin_email" value="<?= get_setting_val('admin_email') ?>">
			</div>
			
			<div class="mb-3">
				<label for="phone_number" class="form-label">Телефон (кликабельний)</label>
				<input type="tel" class="form-control" id="phone_number" name="phone_number" value="<?= get_setting_val('phone_number') ?>" placeholder="+380...">
			</div>

			<div class="mb-3">
				<label for="address" class="form-label">Адреса</label>
				<input type="text" class="form-control" id="address" name="address" value="<?= get_setting_val('address') ?>">
			</div>
			
			<div class="mb-3">
				<label for="meta_description" class="form-label">Meta опис</label>
				<textarea class="form-control" id="meta_description" name="meta_description" rows="2"><?= get_setting_val('meta_description') ?></textarea>
			</div>

			<div class="mb-3">
				<label for="meta_keywords" class="form-label">Meta ключові слова</label>
				<input type="text" class="form-control" id="meta_keywords" name="meta_keywords" value="<?= get_setting_val('meta_keywords') ?>">
			</div>
			
			<!-- СЕКЦІЯ БАНЕРА -->
			<h3 class="mt-5">Банер на головній сторінці</h3>
			
			<div class="mb-4">
				<?php
				// Отримуємо список доступних файлів
				$img_dir = __DIR__ . '/../uploads/cms_img/';
				$available_files = is_dir($img_dir) ? array_values(array_diff(scandir($img_dir), ['.', '..'])) : [];
				?>
				
				<div class="mb-3">
					<label class="form-label">Зображення банера</label>
					<input type="file" class="form-control" name="hero_banner" accept="image/*" id="hero_banner_input" onchange="previewImage(this, 'preview_hero_banner')">
					
					<div class="mt-2">
						<label class="form-label small">Або виберіть з наявних:</label>
						<select class="form-select" name="existing_hero_banner">
							<option value="">— Не обрано —</option>
							<?php foreach ($available_files as $file): ?>
								<?php $selected = (get_setting_val('hero_banner') === '/uploads/cms_img/' . $file) ? 'selected' : ''; ?>
								<option value="<?= htmlspecialchars($file) ?>" <?= $selected ?>>
									<?= htmlspecialchars($file) ?>
								</option>
							<?php endforeach; ?>
						</select>
						<div class="help-text">Виберіть "— Не обрано —" щоб видалити банер</div>
					</div>
					
					<div class="help-text">Рекомендований розмір: 1920x400 пікселів</div>

					<?php if (has_file('hero_banner')): ?>
						<div class="mt-3">
							<img src="<?= get_file_url('hero_banner') ?>" alt="Банер" class="banner-preview" id="preview_hero_banner">
							<br>
							<a href="?delete=hero_banner" class="btn btn-sm btn-outline-danger mt-2"
							   onclick="return confirm('Ви впевнені, що хочете видалити банер?')">Видалити банер</a>
						</div>
					<?php endif; ?>
				</div>
				
				<div class="mb-3">
					<label for="hero_banner_link" class="form-label">Посилання з банера (необов'язково)</label>
					<input type="url" class="form-control" id="hero_banner_link" name="hero_banner_link" value="<?= get_setting_val('hero_banner_link') ?>" placeholder="https://example.com">
					<div class="help-text">Якщо вказано, банер буде клікабельним</div>
				</div>
			</div>
			
			<?php
			$file_fields = [
				'logo_path' => 'Логотип',
				'favicon_path' => 'Фавікон',
				'background_image' => 'Фонове зображення'
			];
			?>

			<!-- СЕКЦІЯ ЗОБРАЖЕНЬ САЙТУ -->
			<h3 class="mt-5">Зображення сайту</h3>

			<?php foreach ($file_fields as $key => $label): ?>
				<div class="mb-4">
					<label class="form-label"><?= $label ?></label>
					<input type="file" class="form-control" name="<?= $key ?>" accept="image/*" id="<?= $key ?>_input" onchange="previewImage(this, 'preview_<?= $key ?>')">
					
					<div class="mt-2">
						<label class="form-label small">Або виберіть з наявних:</label>
						<select class="form-select" name="existing_<?= $key ?>">
							<option value="">— Не обрано —</option>
							<?php foreach ($available_files as $file): ?>
								<?php $selected = (get_setting_val($key) === '/uploads/cms_img/' . $file) ? 'selected' : ''; ?>
								<option value="<?= htmlspecialchars($file) ?>" <?= $selected ?>>
									<?= htmlspecialchars($file) ?>
								</option>
							<?php endforeach; ?>
						</select>
						<div class="help-text">Виберіть "— Не обрано —" щоб видалити зображення</div>
					</div>

					<?php if (has_file($key)): ?>
						<div class="mt-2">
							<img src="<?= get_file_url($key) ?>" alt="<?= $label ?>" class="preview-img" id="preview_<?= $key ?>">
							<br>
							<a href="?delete=<?= urlencode($key) ?>" class="btn btn-sm btn-outline-danger mt-2"
							   onclick="return confirm('Ви впевнені, що хочете видалити файл?')">Видалити</a>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>

			<button type="submit" class="btn btn-primary mt-4">💾 Зберегти всі зміни</button>
		</form>
	</div>

<script>
function previewImage(input, previewId) {
	const preview = document.getElementById(previewId);
	const file = input.files[0];
	if (file && file.type.startsWith('image/')) {
		const reader = new FileReader();
		reader.onload = e => preview.src = e.target.result;
		reader.readAsDataURL(file);
	}
}
</script>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
?>