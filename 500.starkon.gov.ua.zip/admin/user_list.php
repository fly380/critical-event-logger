<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Перевірка прав доступу
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
	header('Location: /templates/login.php');
	exit;
}

require_once __DIR__ . '/functions.php';

$pdo = connectToDatabase();
$error = '';
$users = [];

// Отримання списку користувачів
try {
	$users = getAllUsers($pdo);
} catch (PDOException $e) {
	$error = 'Не вдалося отримати користувачів: ' . $e->getMessage();
}

// Видалення користувача
if (isset($_GET['delete'])) {
	$usernameToDelete = $_GET['delete'];

	if ($usernameToDelete === $_SESSION['username']) {
		$error = 'Ви не можете видалити свій власний обліковий запис.';
	} else {
		try {
			deleteUser($pdo, $usernameToDelete);
			header('Location: user_list.php');
			exit;
		} catch (PDOException $e) {
			$error = 'Не вдалося видалити користувача: ' . $e->getMessage();
		}
	}
}

// Редагування користувача
if (isset($_POST['edit_username'])) {
	$usernameToEdit = $_POST['edit_username'];
	$newPassword = $_POST['edit_password'] ?? '';
	$newRole = $_POST['edit_role'] ?? 'user';

	try {
		updateUser($pdo, $usernameToEdit, $newPassword, $newRole);
		header('Location: user_list.php');
		exit;
	} catch (PDOException $e) {
		$error = 'Не вдалося оновити користувача: ' . $e->getMessage();
	}
}

$page_title = 'Керування користувачами';
ob_start();
?>
<h2 class="mb-4">Список користувачів</h2>
<a href="add_user.php" class="btn btn-success mb-3">Додати користувача</a>
<?php if ($error): ?>
	<div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php elseif (empty($users)): ?>
	<p>Користувачі не знайдені.</p>
<?php else: ?>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Логін</th>
				<th>Роль</th>
				<th>Дії</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($users as $user): ?>
				<tr>
					<td><?= htmlspecialchars($user['login']) ?></td>
					<td><?= htmlspecialchars($user['role']) ?></td>
					<td>
						<button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal" data-username="<?= htmlspecialchars($user['login']) ?>" data-role="<?= htmlspecialchars($user['role']) ?>">Редагувати</button>
						<a href="user_list.php?delete=<?= urlencode($user['login']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Ви впевнені, що хочете видалити користувача?');">Видалити</a>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
<?php endif; ?>

<!-- Модальне вікно для редагування -->
<div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<form action="user_list.php" method="POST">
				<div class="modal-header">
					<h5 class="modal-title" id="editModalLabel">Редагування користувача</h5>
					<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					<input type="hidden" name="edit_username" id="edit_username">
					<div class="mb-3">
						<label for="edit_password" class="form-label">Новий пароль (якщо змінюється)</label>
						<input type="password" class="form-control" id="edit_password" name="edit_password">
					</div>
					<div class="mb-3">
						<label for="edit_role" class="form-label">Роль</label>
						<select class="form-control" name="edit_role" id="edit_role">
						   <option value="user">Користувач</option>
						   <option value="redaktor">Редактор</option>
						   <option value="admin">Адміністратор</option>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрити</button>
					<button type="submit" class="btn btn-primary">Зберегти зміни</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
	var editModal = document.getElementById('editModal');
	editModal.addEventListener('show.bs.modal', function (event) {
		var button = event.relatedTarget;
		var username = button.getAttribute('data-username');
		var role = button.getAttribute('data-role');

		var modalUsernameInput = document.getElementById('edit_username');
		var modalRoleSelect = document.getElementById('edit_role');

		modalUsernameInput.value = username;
		modalRoleSelect.value = role;
	});
</script>

<?php
$content_html = ob_get_clean();
include __DIR__ . '/admin_template.php';
