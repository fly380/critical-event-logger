document.addEventListener('DOMContentLoaded', function () {
    // КНОПКА "БІЛЬШЕ НОВИН"
    const btn = document.getElementById('showMoreBtn');
    
    if (btn) {
        btn.addEventListener('click', function () {
            const hiddenPosts = document.querySelectorAll('.hidden-post');
            const isExpanded = btn.classList.contains('expanded');
            
            hiddenPosts.forEach(function (post) {
                if (isExpanded) {
                    // Ховаємо
                    post.style.setProperty('display', 'none', 'important');
                } else {
                    // Показуємо
                    post.style.setProperty('display', 'flex', 'important');
                }
            });
            
            btn.classList.toggle('expanded');
            btn.textContent = isExpanded ? 'Більше новин' : 'Сховати';
        });
    }
    
    // МОБІЛЬНЕ МЕНЮ
    const mobileMenu = document.getElementById('mobileMenu');
    const toggleBtn = document.querySelector('.mobile-menu-toggle');
    
    if (mobileMenu && toggleBtn) {
        toggleBtn.addEventListener('click', function () {
            mobileMenu.classList.toggle('show');
        });
        
        document.addEventListener('click', function (event) {
            if (!mobileMenu.contains(event.target) && !toggleBtn.contains(event.target)) {
                mobileMenu.classList.remove('show');
            }
        });
    }
    
    // SCROLL TO TOP
    const scrollBtn = document.getElementById('scrollToTop');
    
    if (scrollBtn) {
        window.addEventListener('scroll', function () {
            if (window.pageYOffset > 300) {
                scrollBtn.classList.add('show');
            } else {
                scrollBtn.classList.remove('show');
            }
        });
        
        scrollBtn.addEventListener('click', function () {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
});