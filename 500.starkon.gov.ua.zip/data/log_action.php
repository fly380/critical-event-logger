<?php
if (session_status() === PHP_SESSION_NONE) {
	session_start();
}

function log_action($action, $username = null) {
	// Визначаємо директорію для логів
	$logDir = $_SERVER['DOCUMENT_ROOT'] . '/data/logs/';
	
	// Перевірка на наявність директорії і створення її, якщо потрібно
	if (!is_dir($logDir)) {
		if (!mkdir($logDir, 0755, true)) {
			error_log("Не вдалося створити директорію для логів: $logDir");
			return;
		}
	}

	// Якщо ім'я користувача не задано, використовуємо значення з сесії
	$username = $username ?? ($_SESSION['username'] ?? 'невідомо');
	
	// Форматування рядка для запису в лог
	$line = sprintf("[%s] [%s] %s\n", date('Y-m-d H:i:s'), htmlspecialchars($username), $action);

	// Визначаємо шлях до файлу логу
	$logFile = $logDir . 'activity.log';

	// Запис у лог-файл
	$result = file_put_contents($logFile, $line, FILE_APPEND);

	// Перевірка на успішність запису
	if ($result === false) {
		error_log("Помилка запису в лог: $logFile");
	} else {
		// Логування успішного запису (можливо, не обов'язково для продакшн середовища)
		// error_log("Запис у лог успішний: $logFile");
	}
}
?>
