<?php
// 🛡 Безпечні заголовки
header("Content-Security-Policy: 
default-src 'self'; 
script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com https://fonts.gstatic.com; 
style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; 
font-src 'self' https://fonts.gstatic.com; 
img-src 'self' data:;
");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: no-referrer");
header("X-XSS-Protection: 1; mode=block");

// Безпечні параметри сесії
ini_set('session.cookie_httponly', 1);
if (!empty($_SERVER['HTTPS'])) {
    ini_set('session.cookie_secure', 1);
}

// Встановлюємо час життя cookie сесії — 3600 секунд (1 година)
$cookie_lifetime = 3600;

// Класичний синтаксис для PHP 7.2
session_set_cookie_params(
    $cookie_lifetime,           // lifetime
    '/',                        // path
    '',                         // domain (порожньо = поточний домен)
    !empty($_SERVER['HTTPS']),  // secure
    true                        // httponly
);

// розпочинаємо сесію
session_start();

// Додаємо SameSite cookie через заголовок (для кращої безпеки)
if (!empty($_SERVER['HTTPS']) && session_id()) {
    header('Set-Cookie: ' . session_name() . '=' . session_id() . '; SameSite=Lax', false);
}

require_once __DIR__ . '/data/log_action.php';

// Функція для очищення телефону для tel:
function sanitize_phone_for_tel($phone) {
    return preg_replace('/[^\d\+]/', '', $phone);
}

// Генерація CSRF токена
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$isLoggedIn = $_SESSION['loggedin'] ?? false;
$role = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? 'невідомо';

$currentData = ['title' => '', 'content' => ''];

try {
    $db = new PDO('sqlite:' . __DIR__ . '/data/BD/database.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Завантаження налаштувань сайту
    $stmt = $db->query("SELECT key, value FROM settings");
    $settings = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    function get_setting_val($key) {
        global $settings;
        return htmlspecialchars($settings[$key] ?? '');
    }

    $site_title = $settings['site_title'] ?? 'Сайт';
    $logo_path = $settings['logo_path'] ?? '';
    $backgroundImage = $settings['background_image'] ?? '';
    $bgStyle = $backgroundImage ? "background: url('$backgroundImage') no-repeat center center fixed; background-size: cover;" : "";

    $favicon_path = file_exists(__DIR__ . '/../uploads/cms_img/favicon.ico')
        ? '/uploads/cms_img/favicon.ico'
        : ($settings['favicon_path'] ?? '/assets/images/111.png');

    $footer_text = $settings['footer_text'] ?? '';
    $meta_description = $settings['meta_description'] ?? '';
    $meta_keywords = $settings['meta_keywords'] ?? '';	
    
    // автор
    $author = get_setting_val('site_author') ?: 'Казмірчук Андрій';
    $cmsName = get_setting_val('cms_name') ?: 'fly-CMS';
    $cmsVersion = get_setting_val('cms_version') ?: '1.3.1';

    // Телефон і адреса
    $phone = $settings['phone_number'] ?? '';
    $address = $settings['address'] ?? '';
    $email = $settings['admin_email'] ?? '';

    // Отримуємо дані для банера
    $heroBanner = $settings['hero_banner'] ?? '';
    $heroBannerLink = $settings['hero_banner_link'] ?? '';

    $stmt = $db->query("SELECT title, content FROM main_page WHERE id = 1");
    $currentData = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['title' => '', 'content' => ''];

    if ($isLoggedIn && $_SERVER['REQUEST_METHOD'] === 'POST') {
        // Перевірка CSRF
        if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            die("❌ CSRF токен невірний.");
        }

        $newTitle = trim($_POST['title'] ?? '');
        $newContent = trim($_POST['content'] ?? '');

        // Валідація розміру
        if (mb_strlen($newTitle) > 255 || mb_strlen($newContent) > 10000) {
            die("❌ Забагато тексту.");
        }

        $changes = [];

        if ($newTitle !== $currentData['title']) {
            $changes[] = "заголовок: \"" . $currentData['title'] . "\" → \"$newTitle\"";
        }

        if ($newContent !== $currentData['content']) {
            $changes[] = "вміст змінено";
        }

        if (!empty($changes)) {
            $stmt = $db->prepare("INSERT INTO main_page (id, title, content) VALUES (1, :title, :content)
                                  ON CONFLICT(id) DO UPDATE SET title = excluded.title, content = excluded.content");
            $stmt->execute([':title' => $newTitle, ':content' => $newContent]);

            log_action("Зміни в index.php: " . implode(', ', $changes), $username);
        }

        header("Location: index.php");
        exit;
    }
} catch (PDOException $e) {
    die("Помилка БД: " . htmlspecialchars($e->getMessage()));
}

// Вивід записів (новин)
$postsQuery = "SELECT slug, title, meta_title, content, created_at, thumbnail FROM posts WHERE draft = 0 AND show_on_main = 1";
if (!$isLoggedIn) {
    $postsQuery .= " AND visibility = 'public'";
}
$postsQuery .= " ORDER BY created_at DESC";

$stmt = $db->query($postsQuery);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Визначаємо кількість постів для PHP 7.2
$totalPosts = count($posts);
// Беремо перші 3 новини для початкового відображення
$initialPosts = array_slice($posts, 0, 3);
$remainingPosts = array_slice($posts, 3);
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($site_title . ($currentData['title'] ? ' — ' . $currentData['title'] : '')) ?></title>
    
    <meta name="author" content="<?= htmlspecialchars($author) ?>">
    <meta name="generator" content="<?= htmlspecialchars($cmsName) ?> v<?= htmlspecialchars($cmsVersion) ?>">
    <meta name="description" content="<?= htmlspecialchars($meta_description) ?>">
    <meta name="keywords" content="<?= htmlspecialchars($meta_keywords) ?>">
    
    <link rel="icon" href="<?= htmlspecialchars($favicon_path) ?>" type="image/x-icon">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    
    <!-- Підключення шрифту Kyiv Region -->
    <style>
        @font-face {
            font-family: 'Kyiv Region';
            src: url('/assets/fonts/KyivRegion-Regular.woff2') format('woff2'),
                 url('/assets/fonts/KyivRegion-Regular.woff') format('woff');
            font-weight: normal;
            font-style: normal;
            font-display: swap;
        }
    </style>
    
    <!-- Bootstrap для сітки -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Ваш власний CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">
    
    <style>
        /* Нова кольорова гама */
        :root {
            --primary-brown: #896e57;  /* RGB: 137, 110, 87 */
            --dark-brown: #634e42;      /* RGB: 99, 78, 66 */
            --light-beige: #e0dacc;     /* RGB: 224, 218, 204 */
            --pure-white: #ffffff;       /* RGB: 255, 255, 255 */
            --white-transparent: rgba(255, 255, 255, 0.88);
        }
        
        body {
            font-family: 'Kyiv Region', 'Karla', sans-serif;
            font-size: 17px;
            line-height: 1.65;
            color: var(--ast-global-color-3);
            background-color: var(--light-beige);
            margin: 0;
            padding: 0;
            position: relative;
        }
        
        /* Білий фон з прозорістю 88% */
        body::before {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--white-transparent);
            z-index: -1;
            pointer-events: none;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
            font-weight: 500;
            line-height: 1.3;
            color: var(--dark-brown);
        }
        
        a {
            color: var(--primary-brown);
            text-decoration: none;
            transition: color 0.2s ease;
        }
        
        a:hover {
            color: var(--dark-brown);
            text-decoration: underline;
        }
        
        .site-header {
            background: linear-gradient(135deg, var(--primary-brown) 0%, var(--dark-brown) 100%);
            color: white;
            padding: 1rem 0;
            border-bottom: 1px solid var(--dark-brown);
            position: relative;
            z-index: 10;
        }
        
        .site-header .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .site-branding {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .site-logo img {
            max-height: 60px;
            width: auto;
        }
        
        .site-title {
            font-size: 28px;
            font-weight: 500;
            color: white;
            margin: 0;
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
        }
        
        .main-navigation {
            display: flex;
            gap: 20px;
        }
        
        .main-navigation a {
            color: white;
            font-weight: 500;
            padding: 5px 10px;
            border-radius: 4px;
            text-transform: uppercase;
            font-size: 16px;
        }
        
        .hero-section {
            background: linear-gradient(135deg, var(--primary-brown) 0%, var(--dark-brown) 100%);
            color: white;
            padding: 60px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            margin-bottom: 30px;
            z-index: 10;
        }
        
        .hero-section::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 50px;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none"><path d="M500,97C126.7,96.3,0.8,19.8,0,0v100l1000,0V1C1000,19.4,873.3,97.8,500,97z" fill="%23e0dacc"/></svg>') no-repeat bottom;
            background-size: cover;
        }
        
        .hero-title {
            font-size: 48px;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
        }
        
        .content-area {
            width: 75%;
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 0;
            box-sizing: border-box;
            position: relative;
            z-index: 10;
        }
        
        .section-divider {
            position: relative;
            height: 80px;
            margin: 40px 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .section-divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--primary-brown), transparent);
        }
        
        .section-divider-icon {
            position: relative;
            width: 50px;
            height: 50px;
            background: var(--light-beige);
            border: 2px solid var(--primary-brown);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1;
        }
        
        .section-divider-icon::before {
            content: '↓';
            font-size: 28px;
            line-height: 1;
            color: var(--primary-brown);
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 40px;
            font-size: 32px;
            font-weight: 600;
            color: var(--dark-brown);
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
            position: relative;
            padding-bottom: 15px;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 3px;
            background: var(--primary-brown);
        }
        
        .news-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-top: 20px;
            width: 100%;
        }
        
         .news-card {
            background: var(--pure-white);
            border-radius: 12px;
            overflow: hidden;
            /* ДУЖЕ ПОСИЛЕНІ ТІНІ */
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25),
                        0 3px 10px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(99, 78, 66, 0.4); /* Ще темніша рамка */
            width: 100%;
        }
        
        .news-card:hover {
            transform: translateY(-5px);
            /* МАКСИМАЛЬНО СИЛЬНА ТІНЬ */
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.35),
                        0 10px 20px rgba(0, 0, 0, 0.2);
            border-color: var(--primary-brown);
        }
        
        .news-thumbnail {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-bottom: 2px solid var(--primary-brown);
        }
        
        .news-content {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .news-date {
            font-size: 14px;
            color: var(--primary-brown);
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .news-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 12px;
            line-height: 1.4;
            color: var(--dark-brown);
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
        }
        
        .news-excerpt {
            color: #555;
            margin-bottom: 15px;
            line-height: 1.6;
            font-size: 15px;
            flex: 1;
        }
        
        .read-more {
            color: var(--primary-brown);
            font-weight: 500;
            font-size: 15px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            text-decoration: none;
            margin-top: auto;
            transition: all 0.2s ease;
        }
        
        .read-more:hover {
            color: var(--dark-brown);
        }
        
        .read-more::after {
            content: '›';
            font-size: 20px;
            line-height: 1;
            transition: transform 0.2s ease;
        }
        
        .read-more:hover::after {
            transform: translateX(3px);
        }
        
        .more-news-btn {
            text-align: center;
            margin-top: 30px;
        }
        
        .btn-more-news {
            display: inline-block;
            padding: 12px 40px;
            background: var(--primary-brown);
            color: white;
            border-radius: 50px;
            font-weight: 500;
            font-size: 16px;
            transition: background 0.3s ease, transform 0.2s ease;
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
            border: none;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(99, 78, 66, 0.2);
        }
        
        .btn-more-news:hover {
            background: var(--dark-brown);
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(99, 78, 66, 0.3);
        }
        
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: var(--primary-brown);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            box-shadow: 0 2px 10px rgba(99, 78, 66, 0.3);
            border: none;
        }
        
        .scroll-to-top.show {
            opacity: 1;
            visibility: visible;
        }
        
        .scroll-to-top:hover {
            background: var(--dark-brown);
            transform: scale(1.1);
        }
        
        .scroll-to-top::before {
            content: '↑';
            font-size: 28px;
            line-height: 1;
        }
        
        /* СТИЛІ ДЛЯ БАНЕРА - ВИПРАВЛЕНІ */
        .hero-banner {
            width: 100%;
            margin: 0 0 30px 0;
            position: relative;
            z-index: 5;
            background-color: transparent;
            display: block;
            line-height: 0;
        }
        
        .hero-banner img {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .hero-banner a {
            display: block;
            line-height: 0;
        }
        
        .site-footer {
            background: var(--light-beige);
            border-top: 2px solid var(--primary-brown);
            padding: 50px 20px;
            margin-top: 50px;
            position: relative;
            z-index: 10;
        }
        
        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .footer-widget h3 {
            font-size: 20px;
            margin-bottom: 20px;
            color: var(--dark-brown);
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
        }
        
        .footer-contact-info {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .footer-contact-info li {
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .footer-contact-info li a {
            color: var(--primary-brown);
        }
        
        .copyright {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid var(--primary-brown);
            color: var(--dark-brown);
        }
        
        .mobile-menu-toggle {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            z-index: 20;
        }
        
        .offcanvas {
            position: fixed;
            top: 0;
            right: -280px;
            width: 280px;
            height: 100%;
            background: var(--pure-white);
            box-shadow: -2px 0 10px rgba(99, 78, 66, 0.1);
            transition: right 0.3s ease;
            z-index: 1000;
            border-left: 3px solid var(--primary-brown);
        }
        
        .offcanvas.show {
            right: 0;
        }
        
        .offcanvas-header {
            padding: 20px;
            border-bottom: 1px solid var(--light-beige);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .offcanvas-header h5 {
            color: var(--dark-brown);
            font-family: 'Kyiv Region', 'Rubik', sans-serif;
        }
        
        .offcanvas-body {
            padding: 20px;
        }
        
        .offcanvas-body .nav-item {
            list-style: none;
            margin-bottom: 10px;
        }
        
        .offcanvas-body .nav-link {
            color: var(--dark-brown);
        }
        
        .alert-success {
            background-color: var(--light-beige);
            color: var(--dark-brown);
            padding: 12px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid var(--primary-brown);
        }
        
        /* Стилі для прихованих новин */
        .hidden-post {
            display: none !important;
        }
        
        @media (max-width: 1200px) {
            .content-area {
                width: 85%;
            }
        }
        
        @media (max-width: 992px) {
            .content-area {
                width: 90%;
            }
            .news-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .scroll-to-top {
                bottom: 20px;
                right: 20px;
                width: 40px;
                height: 40px;
            }
        }
        
        @media (max-width: 768px) {
            .main-navigation {
                display: none;
            }
            .mobile-menu-toggle {
                display: block;
            }
            .content-area {
                width: 95%;
                padding: 30px 0;
            }
            .news-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            .section-title {
                font-size: 28px;
            }
            .hero-title {
                font-size: 32px;
            }
            .section-divider {
                height: 60px;
                margin: 30px 0;
            }
            .section-divider-icon {
                width: 40px;
                height: 40px;
            }
            .hero-banner {
                margin: 0 0 20px 0;
            }
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100" style="<?= $bgStyle ?>">
    <header class="site-header">
        <div class="container">
            <div class="site-branding">
                <?php if ($logo_path): ?>
                    <div class="site-logo">
                        <img src="<?= htmlspecialchars($logo_path) ?>" alt="<?= htmlspecialchars($site_title) ?>" height="60">
                    </div>
                <?php endif; ?>
                <div class="site-title"><?= htmlspecialchars($site_title) ?></div>
            </div>
            
            <nav class="main-navigation">
                <?php include __DIR__ . '/templates/menu.php'; ?>
            </nav>
            
            <button class="mobile-menu-toggle">☰</button>
        </div>
    </header>
    
    <!-- БАНЕР ПІД МЕНЮ -->
    <?php if (!empty($heroBanner)): ?>
    <div class="hero-banner">
        <?php if (!empty($heroBannerLink)): ?>
            <a href="<?= htmlspecialchars($heroBannerLink) ?>" target="_blank" rel="noopener noreferrer">
                <img src="<?= htmlspecialchars($heroBanner) ?>" alt="Банер">
            </a>
        <?php else: ?>
            <img src="<?= htmlspecialchars($heroBanner) ?>" alt="Банер">
        <?php endif; ?>
    </div>
    <?php endif; ?>
    

    
    <main class="content-area">
        <!-- НОВИНИ -->
        <?php if (!empty($posts)): ?>
            <section class="news-section">
                <h2 class="section-title">Новини</h2>
                
                <div class="news-grid">
                    <!-- Перші 3 новини (завжди видимі) -->
                    <?php foreach ($initialPosts as $post): ?>
                        <?php
                            $thumbnailWebPath = $post['thumbnail'] ?? '';
                            $thumbnailWebPath = preg_replace('#^\.\./#', '/', $thumbnailWebPath);
                            $thumbnailFilePath = realpath($_SERVER['DOCUMENT_ROOT'] . $thumbnailWebPath);
                            $hasThumbnail = !empty($thumbnailWebPath) && $thumbnailFilePath && file_exists($thumbnailFilePath);
                        ?>
                        <article class="news-card">
                            <?php if ($hasThumbnail): ?>
                                <img src="<?= htmlspecialchars($post['thumbnail']) ?>" alt="<?= htmlspecialchars($post['meta_title'] ?? '') ?>" class="news-thumbnail">
                            <?php endif; ?>
                            
                            <div class="news-content">
                                <div class="news-date"><?= date("d.m.Y", strtotime($post['created_at'])) ?></div>
                                <h3 class="news-title"><?= htmlspecialchars($post['meta_title'] ?? '') ?></h3>
                                <p class="news-excerpt"><?= htmlspecialchars(mb_strimwidth(strip_tags($post['content']), 0, 150, '...')) ?></p>
                                <a href="/<?= urlencode($post['slug']) ?>" class="read-more">Більше</a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                    
                    <!-- Решта новин (приховані) -->
                    <?php if (!empty($remainingPosts)): ?>
                        <?php foreach ($remainingPosts as $post): ?>
                            <?php
                                $thumbnailWebPath = $post['thumbnail'] ?? '';
                                $thumbnailWebPath = preg_replace('#^\.\./#', '/', $thumbnailWebPath);
                                $thumbnailFilePath = realpath($_SERVER['DOCUMENT_ROOT'] . $thumbnailWebPath);
                                $hasThumbnail = !empty($thumbnailWebPath) && $thumbnailFilePath && file_exists($thumbnailFilePath);
                            ?>
                            <article class="news-card hidden-post">
                                <?php if ($hasThumbnail): ?>
                                    <img src="<?= htmlspecialchars($post['thumbnail']) ?>"
                                         alt="<?= htmlspecialchars($post['meta_title'] ?? '') ?>"
                                         class="news-thumbnail">
                                <?php endif; ?>

                                <div class="news-content">
                                    <div class="news-date">
                                        <?= date("d.m.Y", strtotime($post['created_at'])) ?>
                                    </div>

                                    <h3 class="news-title">
                                        <?= htmlspecialchars($post['meta_title'] ?? '') ?>
                                    </h3>

                                    <p class="news-excerpt">
                                        <?= htmlspecialchars(mb_strimwidth(strip_tags($post['content']), 0, 150, '...')) ?>
                                    </p>

                                    <a href="/<?= urlencode($post['slug']) ?>" class="read-more">
                                        Більше
                                    </a>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($remainingPosts)): ?>
                    <div class="more-news-btn">
                        <button class="btn-more-news" id="showMoreBtn">Більше новин</button>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
        
        <!-- Гарний візуальний перехід -->
        <?php if (!empty($posts) && (!empty($currentData['title']) || !empty($currentData['content']))): ?>
            <div class="section-divider">
                <div class="section-divider-icon"></div>
            </div>
        <?php endif; ?>
        
        <!-- ОСНОВНИЙ КОНТЕНТ -->
        <?php if (!empty($currentData['title']) || !empty($currentData['content'])): ?>
            <section class="main-content-block">
                <?php if (!empty($currentData['title'])): ?>
                    <h2 class="section-title"><?= htmlspecialchars($currentData['title']) ?></h2>
                <?php endif; ?>
                
                <?php if (!empty($currentData['content'])): ?>
                    <div class="content-wrapper bg-white p-4 rounded shadow-sm">
                        <?= is_array($currentData['content']) ? ($currentData['content']['html'] ?? '') : $currentData['content'] ?>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    </main>
    
    <footer class="site-footer">
        <div class="footer-grid">
            <div class="footer-widget">
                <h3>Про нас</h3>
                <p>Сайт створено на базі власної CMS для зручного керування контентом.</p>
                <?php if (!empty($address)): ?>
                    <p><strong>Адреса:</strong> <?= nl2br(htmlspecialchars($address)) ?></p>
                <?php endif; ?>
            </div>
            
            <div class="footer-widget">
                <h3>Контакти</h3>
                <ul class="footer-contact-info">
                    <?php if (!empty($phone)): ?>
                        <li>📞 <a href="tel:<?= sanitize_phone_for_tel($phone) ?>"><?= htmlspecialchars($phone) ?></a></li>
                    <?php endif; ?>
                    <?php if (!empty($email)): ?>
                        <li>✉️ <a href="mailto:<?= htmlspecialchars($email) ?>"><?= htmlspecialchars($email) ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <div class="copyright">
            <small><?= $footer_text ?: '&copy; ' . date('Y') . ' ' . htmlspecialchars($site_title) ?></small>
        </div>
    </footer>
    
    <!-- Mobile Menu Offcanvas -->
    <div class="offcanvas" id="mobileMenu">
        <div class="offcanvas-header">
            <h5>Меню</h5>
            <button class="btn-close" onclick="toggleMobileMenu()">✕</button>
        </div>
        <div class="offcanvas-body">
            <?php $vertical = true; include __DIR__ . '/templates/menu.php'; ?>
        </div>
    </div>
    
    <!-- Кнопка прокрутки догори -->
    <button class="scroll-to-top" id="scrollToTop"></button>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/main.js"></script>
</body>
</html>