<?php
// Безпечні параметри сесії
ini_set('session.cookie_httponly', 1);
if (!empty($_SERVER['HTTPS'])) {
	ini_set('session.cookie_secure', 1);
}

// Встановлюємо час життя cookie сесії — 3600 секунд (1 година)
$cookie_lifetime = 3600;

session_set_cookie_params([
	'lifetime' => $cookie_lifetime,
	'path' => '/',
	'httponly' => true,
	'secure' => !empty($_SERVER['HTTPS']), // встановлюй secure, якщо HTTPS
	'samesite' => 'Lax',
]);
// Старт сесії
session_start();

// Максимальний час неактивності (наприклад, 3600 сек = 1 година)
$max_inactive = 3600;

if (isset($_SESSION['last_activity']) && time() - $_SESSION['last_activity'] > $max_inactive) {
	// Занадто довга неактивність — знищуємо сесію
	session_unset();
	session_destroy();
	session_start(); // Запускаємо нову сесію
}
$_SESSION['last_activity'] = time();

// підключаємо логи
require_once __DIR__ . '/../data/log_action.php';

// Генерація CSRF токена
if (empty($_SESSION['csrf_token'])) {
	$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Обмеження спроб входу
if (!isset($_SESSION['login_attempts'])) {
	$_SESSION['login_attempts'] = 0;
}

$error = '';

// Функція для отримання налаштувань з таблиці settings
function get_setting($key) {
	try {
		$pdo = new PDO('sqlite:' . $_SERVER['DOCUMENT_ROOT'] . '/data/BD/database.sqlite');
		$stmt = $pdo->prepare("SELECT value FROM settings WHERE key = :key");
		$stmt->execute(['key' => $key]);
		return $stmt->fetchColumn() ?: null;
	} catch (PDOException $e) {
		return null;
	}
}

// Отримуємо налаштування reCAPTCHA
$recaptcha_enabled = get_setting('recaptcha_enabled') === 'on';
$recaptcha_site_key = get_setting('recaptcha_site_key');
$recaptcha_secret_key = get_setting('recaptcha_secret_key');

// Обробка форми
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	// CSRF перевірка
	if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
		$error = 'Невірний токен безпеки.';
	} elseif ($_SESSION['login_attempts'] >= 5) {
		$error = 'Забагато невдалих спроб входу. Спробуйте пізніше.';
	} else {
		// Перевірка reCAPTCHA
		if ($recaptcha_enabled) {
			$recaptcha_token = $_POST['recaptcha_token'] ?? '';
			$recaptcha_response = file_get_contents(
				'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($recaptcha_secret_key) .
				'&response=' . urlencode($recaptcha_token)
			);
			$recaptcha_data = json_decode($recaptcha_response, true);
			if (!$recaptcha_data['success'] || $recaptcha_data['score'] < 0.5) {
				$error = 'Перевірка reCAPTCHA не пройдена.';
			}
		}

		if (!$error) {
			$username = trim($_POST['login'] ?? '');
			$password = $_POST['password'] ?? '';

			if (empty($username) || empty($password)) {
				$error = 'Усі поля обовʼязкові.';
			} else {
				try {
					$pdo = new PDO('sqlite:' . $_SERVER['DOCUMENT_ROOT'] . '/data/BD/database.sqlite');
					$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

					$stmt = $pdo->prepare("SELECT * FROM users WHERE login = :login");
					$stmt->bindParam(':login', $username, PDO::PARAM_STR);
					$stmt->execute();
					$user = $stmt->fetch(PDO::FETCH_ASSOC);

					if ($user && password_verify($password, $user['password'])) {
					// 🔐 Генеруємо новий ID сесії
					session_regenerate_id(true);

					$_SESSION['loggedin'] = true;
					$_SESSION['username'] = $username;
					$_SESSION['role'] = $user['role'];
					log_action("Вхід ({$user['role']})", $username);
					$_SESSION['login_attempts'] = 0;
					unset($_SESSION['csrf_token']);

					 header('Location: /index.php');
					 exit;
					}
					else {
					sleep(1); // Затримка на 1 секунду при невдачі
					$_SESSION['login_attempts']++;
					$ip = $_SERVER['REMOTE_ADDR'] ?? 'невідомо';
					log_action("❌ Невдала спроба входу", "Логін: {$username}, IP: {$ip}");
					$error = 'Невірний логін або пароль.';
					}

				} catch (PDOException $e) {
					error_log('DB error: ' . $e->getMessage());
					$error = 'Помилка бази даних. Спробуйте пізніше.';
				}
			}
		}
	}
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
	<meta charset="UTF-8">
	<title>Вхід</title>
	<link rel="icon" href="/assets/images/favicon.ico" type="image/x-icon">
	<link rel="stylesheet" href="/assets/css/login.css" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<?php if ($recaptcha_enabled && $recaptcha_site_key): ?>
	<script src="https://www.google.com/recaptcha/api.js?render=<?= htmlspecialchars($recaptcha_site_key) ?>"></script>
	<script>
		grecaptcha.ready(function () {
			grecaptcha.execute('<?= htmlspecialchars($recaptcha_site_key) ?>', {action: 'login'}).then(function (token) {
				document.getElementById('recaptcha_token').value = token;
			});
		});
	</script>
	<?php endif; ?>
</head>
<body class="bg-light">
<div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
	<div class="login-form bg-white p-4 shadow rounded" style="max-width: 400px; width: 100%;">
		<h3 class="text-center mb-4">Вхід до системи</h3>
		<?php if ($error): ?>
			<div class="alert alert-danger"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
		<?php endif; ?>
		<form method="post" class="border p-3 rounded shadow-sm bg-light">
			<div class="mb-3">
				<label for="login" class="form-label">Логін</label>
				<input type="text" class="form-control" id="login" name="login" required>
			</div>
			<div class="mb-3">
				<label for="password" class="form-label">Пароль</label>
				<input type="password" class="form-control" id="password" name="password" required>
			</div>
			<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
			<?php if ($recaptcha_enabled && $recaptcha_site_key): ?>
				<input type="hidden" name="recaptcha_token" id="recaptcha_token">
			<?php endif; ?>
			<button type="submit" class="btn btn-primary w-100">Увійти</button>
		</form>
	</div>
</div>
</body>
</html>
