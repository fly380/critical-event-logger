<?php
// 🛡 Безпечні заголовки (мають бути до будь-якого виводу!)
header("Content-Security-Policy: default-src 'self'; script-src 'self' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; font-src 'self' https://cdn.jsdelivr.net; img-src 'self' data:;");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: no-referrer");
header("X-XSS-Protection: 1; mode=block");

session_start();
require_once __DIR__ . '/../data/log_action.php';

$backgroundImage = null;
$bgStyle = '';

try {
	$db_settings = new PDO('sqlite:' . __DIR__ . '/../data/BD/database.sqlite');
	$db_settings->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$stmt = $db_settings->prepare("SELECT value FROM settings WHERE key = 'background_image'");
	$stmt->execute();
	$result = $stmt->fetch(PDO::FETCH_ASSOC);
	$backgroundImage = $result['value'] ?? null;
	if ($backgroundImage) {
		$bgStyle = "background: url('$backgroundImage') no-repeat center center fixed; background-size: cover;";
	}
} catch (PDOException $e) {
	$bgStyle = '';
}

$isLoggedIn = $_SESSION['loggedin'] ?? false;
$role = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? 'невідомо';

$slug = $_GET['page'] ?? '';
if (!preg_match('/^[a-zA-Z0-9_-]+$/', $slug)) {
	http_response_code(400);
	include __DIR__ . '/../templates/errors/400.php';
	exit;
}

try {
	$db = new PDO('sqlite:' . __DIR__ . '/../data/BD/database.sqlite');
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
	http_response_code(500);
	include __DIR__ . '/../templates/errors/500.php';
	exit;
}

// Шукаємо спочатку серед сторінок
$stmt = $db->prepare("SELECT *, 'page' as type FROM pages WHERE slug = :slug");
$stmt->execute([':slug' => $slug]);
$page = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$page) {
	// Якщо не знайдено, шукаємо серед записів
	$stmt = $db->prepare("SELECT *, 'post' as type FROM posts WHERE slug = :slug");
	$stmt->execute([':slug' => $slug]);
	$page = $stmt->fetch(PDO::FETCH_ASSOC);
	if (!$page) {
		http_response_code(404);
		include __DIR__ . '/../templates/errors/404.php';
		exit;
	}
}

if ($page['draft'] && !$isLoggedIn) {
	http_response_code(403);
	include __DIR__ . '/../templates/errors/403_draft.php';
	exit;
}
if (($page['visibility'] ?? 'public') === 'private' && !$isLoggedIn) {
	http_response_code(403);
	include __DIR__ . '/../templates/errors/403_private.php';
	exit;
}

// SEO мета з posts, якщо є
if ($page['type'] === 'post') {
	$meta_title = $page['meta_title'] ?? $page['title'] ?? '';
	$meta_description = $page['meta_description'] ?? '';
	$page['custom_css'] = $page['custom_css'] ?? '';
	$page['custom_js'] = $page['custom_js'] ?? '';
} else {
	$meta_title = $page['title'] ?? '';
	$meta_description = '';
}

$pageData = $page;
$title = $meta_title;
$contentHtml = $page['content'] ?? '';

require __DIR__ . '/../templates/page_wrapper.php';
