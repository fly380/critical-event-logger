<?php
// 🛡 Безпечні заголовки
header("Content-Security-Policy: 
default-src 'self'; 
script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com https://fonts.gstatic.com; 
style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; 
font-src 'self' https://fonts.gstatic.com; 
img-src 'self' data:;
");
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: SAMEORIGIN");
header("Referrer-Policy: no-referrer");
header("X-XSS-Protection: 1; mode=block");

function get_setting($key) {
	try {
		$db = new PDO('sqlite:' . __DIR__ . '/../data/BD/database.sqlite');
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt = $db->prepare("SELECT value FROM settings WHERE key = :key");
		$stmt->execute([':key' => $key]);
		$result = $stmt->fetch(PDO::FETCH_ASSOC);
		return $result['value'] ?? null;
	} catch (PDOException $e) {
		return null;
	}
}

// Завантаження налаштувань
$site_title = get_setting('site_title') ?: 'Сайт';
$meta_description = get_setting('meta_description');
$meta_keywords = get_setting('meta_keywords');
$logo_path = get_setting('logo_path') ?: '/assets/images/111.png';
$favicon_path = file_exists(__DIR__ . '/../uploads/cms_img/favicon.ico')
	? '/uploads/cms_img/favicon.ico'
	: (get_setting('favicon_path') ?: '/assets/images/111.png');
$footer_text = get_setting('footer_text');
$backgroundImage = get_setting('background_image');
$phone = get_setting('phone_number');
$address = get_setting('address');
$email = get_setting('admin_email');
$author = get_setting('site_author') ?: 'Казмірчук Андрій';
$cmsName = get_setting('cms_name') ?: 'fly-CMS';
$cmsVersion = get_setting('cms_version') ?: '1.3.1';

$bgStyle = $backgroundImage ? "background: url('$backgroundImage') no-repeat center center fixed; background-size: cover;" : '';

function sanitize_phone_for_tel($phone) {
	// Залишаємо цифри і плюс для міжнародного формату
	return preg_replace('/[^\d\+]/', '', $phone);
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?= htmlspecialchars($site_title . (!empty($title) ? ' — ' . $title : '')) ?></title>
	
	<meta name="author" content="<?= htmlspecialchars($author) ?>">
	<meta name="generator" content="<?= htmlspecialchars($cmsName) ?> v<?= htmlspecialchars($cmsVersion) ?>">
	<meta name="description" content="<?= htmlspecialchars($meta_description) ?>">
	<meta name="keywords" content="<?= htmlspecialchars($meta_keywords) ?>">
	
	<link rel="icon" href="<?= htmlspecialchars($favicon_path) ?>" type="image/x-icon">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	
	<!-- Підключення шрифту Kyiv Region -->
	<style>
		@font-face {
			font-family: 'Kyiv Region';
			src: url('/assets/fonts/KyivRegion-Regular.woff2') format('woff2'),
				 url('/assets/fonts/KyivRegion-Regular.woff') format('woff');
			font-weight: normal;
			font-style: normal;
			font-display: swap;
		}
	</style>
	
	<!-- Bootstrap для сітки -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
	
	<!-- Ваш власний CSS -->
	<link rel="stylesheet" href="/assets/css/style.css" />
	
	<style>
		/* Нова кольорова гама - така ж як в index.php */
		:root {
			--primary-brown: #896e57;  /* RGB: 137, 110, 87 */
			--dark-brown: #634e42;      /* RGB: 99, 78, 66 */
			--light-beige: #e0dacc;     /* RGB: 224, 218, 204 */
			--pure-white: #ffffff;       /* RGB: 255, 255, 255 */
			--white-transparent: rgba(255, 255, 255, 0.88);
		}
		
		body {
			font-family: 'Kyiv Region', 'Karla', sans-serif;
			font-size: 17px;
			line-height: 1.65;
			color: #555;
			background-color: var(--light-beige);
			margin: 0;
			padding: 0;
			position: relative;
			min-height: 100vh;
		}
		
		/* Білий фон з прозорістю 88% */
		body::before {
			content: '';
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			bottom: 0;
			background-color: var(--white-transparent);
			z-index: -1;
			pointer-events: none;
		}
		
		h1, h2, h3, h4, h5, h6 {
			font-family: 'Kyiv Region', 'Rubik', sans-serif;
			font-weight: 500;
			line-height: 1.3;
			color: var(--dark-brown);
		}
		
		a {
			color: var(--primary-brown);
			text-decoration: none;
			transition: color 0.2s ease;
		}
		
		a:hover {
			color: var(--dark-brown);
			text-decoration: underline;
		}
		
		.site-header {
			background: linear-gradient(135deg, var(--primary-brown) 0%, var(--dark-brown) 100%);
			color: white;
			padding: 1rem 0;
			border-bottom: 1px solid var(--dark-brown);
			position: fixed;
			top: 0;
			left: 0;
			right: 0;
			z-index: 1030;
			box-shadow: 0 2px 10px rgba(0,0,0,0.1);
		}
		
		.site-header .container {
			display: flex;
			align-items: center;
			justify-content: space-between;
			max-width: 1200px;
			margin: 0 auto;
			padding: 0 20px;
		}
		
		.site-branding {
			display: flex;
			align-items: center;
			gap: 15px;
		}
		
		.site-logo img {
			max-height: 60px;
			width: auto;
		}
		
		.site-title {
			font-size: 28px;
			font-weight: 500;
			color: white;
			margin: 0;
			font-family: 'Kyiv Region', 'Rubik', sans-serif;
		}
		
		.main-navigation {
			display: flex;
			gap: 20px;
		}
		
		.main-navigation a {
			color: white;
			font-weight: 500;
			padding: 5px 10px;
			border-radius: 4px;
			text-transform: uppercase;
			font-size: 16px;
		}
		
		.main-navigation a:hover {
			background: rgba(255,255,255,0.1);
			color: white;
			text-decoration: none;
		}
		
		.mobile-menu-toggle {
			display: none;
			background: none;
			border: none;
			color: white;
			font-size: 28px;
			cursor: pointer;
			z-index: 20;
			line-height: 1;
			padding: 5px 10px;
		}
		
		.mobile-menu-toggle:hover {
			background: rgba(255,255,255,0.1);
			border-radius: 4px;
		}
		
		.content-wrapper {
			background: var(--pure-white);
			border-radius: 12px;
			box-shadow: 0 10px 30px rgba(0, 0, 0, 0.25),
						0 3px 10px rgba(0, 0, 0, 0.15);
			border: 1px solid rgba(99, 78, 66, 0.4);
			padding: 30px !important;
			margin: 20px 0 40px 0;
		}
		
		.content-wrapper h2 {
			margin-top: 0;
			margin-bottom: 25px;
			font-size: 32px;
			font-weight: 600;
			color: var(--dark-brown);
			position: relative;
			padding-bottom: 15px;
			border-bottom: 3px solid var(--primary-brown);
		}
		
		.content-wrapper h2:after {
			display: none; /* Прибираємо ::after з Bootstrap */
		}
		
		.site-footer {
			background: var(--light-beige);
			border-top: 2px solid var(--primary-brown);
			padding: 50px 20px 30px;
			margin-top: 50px;
			position: relative;
			z-index: 10;
		}
		
		.footer-grid {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
			gap: 30px;
			max-width: 1200px;
			margin: 0 auto;
		}
		
		.footer-widget h3 {
			font-size: 20px;
			margin-bottom: 20px;
			color: var(--dark-brown);
			font-family: 'Kyiv Region', 'Rubik', sans-serif;
		}
		
		.footer-contact-info {
			list-style: none;
			padding: 0;
			margin: 0;
		}
		
		.footer-contact-info li {
			margin-bottom: 10px;
			display: flex;
			align-items: center;
			gap: 10px;
		}
		
		.footer-contact-info li a {
			color: var(--primary-brown);
		}
		
		.copyright {
			text-align: center;
			margin-top: 30px;
			padding-top: 20px;
			border-top: 1px solid var(--primary-brown);
			color: var(--dark-brown);
		}
		
		/* Offcanvas стилі */
		.offcanvas {
			position: fixed;
			top: 0;
			right: -300px;
			width: 280px;
			height: 100%;
			background: var(--pure-white);
			box-shadow: -5px 0 25px rgba(0,0,0,0.2);
			transition: right 0.3s ease;
			z-index: 1050;
			border-left: 3px solid var(--primary-brown);
		}
		
		.offcanvas.show {
			right: 0;
		}
		
		.offcanvas-header {
			padding: 20px;
			border-bottom: 1px solid var(--light-beige);
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: var(--light-beige);
		}
		
		.offcanvas-header h5 {
			color: var(--dark-brown);
			font-family: 'Kyiv Region', 'Rubik', sans-serif;
			margin: 0;
			font-size: 20px;
		}
		
		.btn-close {
			background: none;
			border: none;
			font-size: 24px;
			cursor: pointer;
			color: var(--dark-brown);
			line-height: 1;
			padding: 5px 10px;
		}
		
		.btn-close:hover {
			background: rgba(99,78,66,0.1);
			border-radius: 4px;
		}
		
		.offcanvas-body {
			padding: 20px;
		}
		
		.offcanvas-body ul {
			list-style: none;
			padding: 0;
			margin: 0;
		}
		
		.offcanvas-body li {
			margin-bottom: 12px;
		}
		
		.offcanvas-body a {
			color: var(--dark-brown);
			font-size: 18px;
			display: block;
			padding: 8px 12px;
			border-radius: 6px;
			transition: all 0.2s ease;
		}
		
		.offcanvas-body a:hover {
			background: var(--light-beige);
			color: var(--primary-brown);
			text-decoration: none;
			padding-left: 20px;
		}
		
		/* Кнопка прокрутки догори */
		.scroll-to-top {
			position: fixed;
			bottom: 30px;
			right: 30px;
			width: 50px;
			height: 50px;
			background: var(--primary-brown);
			color: white;
			border-radius: 50%;
			display: flex;
			align-items: center;
			justify-content: center;
			cursor: pointer;
			transition: all 0.3s ease;
			z-index: 999;
			opacity: 0;
			visibility: hidden;
			box-shadow: 0 2px 10px rgba(99, 78, 66, 0.3);
			border: none;
		}
		
		.scroll-to-top.show {
			opacity: 1;
			visibility: visible;
		}
		
		.scroll-to-top:hover {
			background: var(--dark-brown);
			transform: scale(1.1);
			box-shadow: 0 4px 15px rgba(99, 78, 66, 0.4);
		}
		
		.scroll-to-top::before {
			content: '↑';
			font-size: 28px;
			line-height: 1;
		}
		
		/* Адаптивність */
		@media (max-width: 992px) {
			.main-navigation {
				display: none;
			}
			.mobile-menu-toggle {
				display: block;
			}
			.site-title {
				font-size: 24px;
			}
		}
		
		@media (max-width: 768px) {
			.site-header .container {
				padding: 0 15px;
			}
			.site-logo img {
				max-height: 45px;
			}
			.site-title {
				font-size: 20px;
			}
			.content-wrapper {
				padding: 20px !important;
				margin: 15px 0 30px 0;
			}
			.content-wrapper h2 {
				font-size: 26px;
				margin-bottom: 20px;
				padding-bottom: 10px;
			}
			.scroll-to-top {
				bottom: 20px;
				right: 20px;
				width: 40px;
				height: 40px;
			}
		}
		
		@media (max-width: 480px) {
			.site-title {
				font-size: 18px;
			}
			.content-wrapper {
				padding: 15px !important;
			}
		}
		
		<?php if (!empty($pageData['custom_css'])): ?>
			/* Користувацькі CSS */
			<?= $pageData['custom_css'] ?>
		<?php endif; ?>
	</style>
</head>
<body class="d-flex flex-column min-vh-100" style="<?= htmlspecialchars($bgStyle) ?>">
	<header class="site-header">
		<div class="container">
			<div class="site-branding">
				<?php if ($logo_path): ?>
					<div class="site-logo">
						<img src="<?= htmlspecialchars($logo_path) ?>" alt="<?= htmlspecialchars($site_title) ?>" height="60">
					</div>
				<?php endif; ?>
				<div class="site-title"><?= htmlspecialchars($site_title) ?></div>
			</div>
			
			<nav class="main-navigation">
				<?php include __DIR__ . '/menu.php'; ?>
			</nav>
			
			<button class="mobile-menu-toggle" onclick="toggleMobileMenu()">☰</button>
		</div>
	</header>
	
	<main class="flex-fill" style="padding-top: 100px;">
		<div class="container">
			<div class="content-wrapper">
				<?php if (!empty($title)): ?>
					<h2><?= htmlspecialchars($title) ?></h2>
				<?php endif; ?>
				
				<?= $contentHtml ?>
			</div>
		</div>
	</main>
	
	<footer class="site-footer">
		<div class="footer-grid">
			<div class="footer-widget">
				<h3>Про нас</h3>
				<p>Сайт створено на базі власної CMS для зручного керування контентом.</p>
				<?php if (!empty($address)): ?>
					<p><strong>Адреса:</strong> <?= nl2br(htmlspecialchars($address)) ?></p>
				<?php endif; ?>
			</div>
			
			<div class="footer-widget">
				<h3>Контакти</h3>
				<ul class="footer-contact-info">
					<?php if (!empty($phone)): ?>
						<li>📞 <a href="tel:<?= sanitize_phone_for_tel($phone) ?>"><?= htmlspecialchars($phone) ?></a></li>
					<?php endif; ?>
					<?php if (!empty($email)): ?>
						<li>✉️ <a href="mailto:<?= htmlspecialchars($email) ?>"><?= htmlspecialchars($email) ?></a></li>
					<?php endif; ?>
				</ul>
			</div>
		</div>
		
		<div class="copyright">
			<small><?= $footer_text ?: '&copy; ' . date('Y') . ' ' . htmlspecialchars($site_title) ?></small>
		</div>
	</footer>
	
	<!-- Mobile Menu Offcanvas -->
	<div class="offcanvas" id="mobileMenu">
		<div class="offcanvas-header">
			<h5>Меню</h5>
			<button class="btn-close" onclick="toggleMobileMenu()">✕</button>
		</div>
		<div class="offcanvas-body">
			<?php $vertical = true; include __DIR__ . '/menu.php'; ?>
		</div>
	</div>
	
	<!-- Кнопка прокрутки догори -->
	<button class="scroll-to-top" id="scrollToTop"></button>
	
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
	<script>
		// Мобільне меню
		function toggleMobileMenu() {
			document.getElementById('mobileMenu').classList.toggle('show');
		}
		
		// Закриваємо меню при кліку поза ним
		document.addEventListener('click', function(event) {
			const mobileMenu = document.getElementById('mobileMenu');
			const toggleBtn = document.querySelector('.mobile-menu-toggle');
			
			if (mobileMenu.classList.contains('show') && 
				!mobileMenu.contains(event.target) && 
				!toggleBtn.contains(event.target)) {
				mobileMenu.classList.remove('show');
			}
		});
		
		// Кнопка прокрутки догори
		const scrollToTopBtn = document.getElementById('scrollToTop');
		
		window.addEventListener('scroll', function() {
			if (window.scrollY > 300) {
				scrollToTopBtn.classList.add('show');
			} else {
				scrollToTopBtn.classList.remove('show');
			}
		});
		
		scrollToTopBtn.addEventListener('click', function() {
			window.scrollTo({
				top: 0,
				behavior: 'smooth'
			});
		});
		
		<?php if (!empty($pageData['custom_js'])): ?>
			// Користувацькі JS
			<?= $pageData['custom_js'] ?>
		<?php endif; ?>
	</script>
</body>
</html>